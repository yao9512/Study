package com.yao;

import java.util.Random;

import javax.swing.ImageIcon;

public class Boss extends Plane{
	public int flyMiles_boss = 1;
	ImageIcon pics[] = new ImageIcon[4];

	int direction = 12;
	volatile int embercount;

	Boss(int stage){
		for(int i=0;i<4;i++) {
			pics[i] = new ImageIcon(Enemy.class.getResource("airplane_ember"+i+".png"));
		}
		state = false;
		level = stage*10;
		firepower = 5;
		this.setVisible(false);
		setBounds(50, 50, width, height);
		
	}
	@Override
	public void move() {
		if(this.state) {
			if(y<=0 && direction>0 && direction<8) {
				Random rand = new Random();
				direction = rand.nextInt(9)+8;
				if(direction == 16)
					direction = 0;

			}else if(y >=Game.Gameheight/3 && direction>8 && direction<16) {
				Random rand = new Random();
				direction = rand.nextInt(9);

			}else if(x <= 0 && direction>4 && direction<12) {
				Random rand = new Random();
				direction = rand.nextInt(9)+12;
				if(direction >= 16)
					direction -= 16;
			}else if(x >= (Game.Gamewidth-width) && ((direction>=0 && direction<4) || (direction>12 && direction<16))) {
				Random rand = new Random();
				direction = rand.nextInt(9)+4;
			}else{
				

				if(direction<4) {

					if(direction == 0) {
						x += flyMiles_boss;
					}else {
						x += flyMiles_boss;
						y -= (int)(((Math.pow(2.0, direction-1))/2)*flyMiles_boss);
					}
						
				}else if(direction<8) {
					if(direction == 4) {
						y -= flyMiles_boss;
					}else {
						x -= flyMiles_boss;
						y -= (int)((1/(Math.pow(2.0, -(direction-6))))*flyMiles_boss);
					}
				}else if(direction<12) {
					if(direction == 8) {
						x -= flyMiles_boss;
					}else {

						x -= flyMiles_boss;
						y += (int)(((Math.pow(2.0, direction-8))/2)*flyMiles_boss);
					}
				}else if(direction<16) {
					if(direction == 12) {
						y += flyMiles_boss;
					}else {
						x += flyMiles_boss;
						y += (int)((1/(Math.pow(2.0, -(direction-8-4))))*flyMiles_boss);

					}
				}
				
				setBounds(x, y, width, height);
			}
		}
	}


	@Override
	public boolean impact(Plane plane) {
		return false;
		// TODO Auto-generated method stub

	}

	@Override
	public boolean fire() {
		return false;
	}

	@Override
	public void move(boolean up, boolean down, boolean left, boolean right) {
		// TODO Auto-generated method stub

	}

	@Override
	public void dead() {
		this.setVisible(false);
		this.state = false;
		this.x = -width*15;
		this.y = -height*2;
	}
	@Override
	public boolean isAlive() {
		if((!this.state) && (this.health<=0)) {
			return false;
		}else {
			return true;

		}		
	}
	@Override
	public void ember() {
		embercount++;
		if(embercount%10 == 0) {
			this.setIcon(pics[embercount/10]);
		}
		if(embercount == 30) {
			this.dead();
			this.state = false;
			embercount = 0;
		}		
	}

}
