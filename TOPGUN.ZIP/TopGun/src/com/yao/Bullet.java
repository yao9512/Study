package com.yao;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Bullet extends JLabel{

	int x = -100;
	int y = -100;
	int level;
	int embercount;

	ImageIcon pics[] = new ImageIcon[4];
	ImageIcon image = new ImageIcon(Bullet.class.getResource("bullet.png"));
	ImageIcon image1 = new ImageIcon(Bullet.class.getResource("bullet1.png"));

	boolean validity = true;
	boolean explode = false;
	Bullet(int x,int y,int level,boolean ishero){
		this.x = x;
		this.y = y;
		this.level = level;
		if(ishero) {
			this.setIcon(image);
		}else {
			this.setIcon(image1 );
		}
		validity = true;
	}
	public Bullet() {
	}
	public boolean isHitted(Plane plane,boolean valid) {
		if(this.x>=plane.x && this.x<=plane.x+plane.width && this.y>=plane.y && this.y<=plane.y+plane.height) {
			if(valid) {
				plane.health -= level;
			}
			validity = false;
			return true;

		}else {
			return false;
		}

	}
	public void move(boolean isHero) {

		if(isHero) {
			if(this.y>0 && validity) {
				if(level == 100) {
					this.y-=2;
				}else {
					this.y-=1;
					this.setSize(image.getIconWidth(), image.getIconHeight());
				}
				this.setLocation(x, y);
			}else {
				validity = false;
			}
		}else {
			if(this.y<Game.Gameheight && validity) {
				this.y+=1;
				this.setBounds(x, y, image.getIconWidth(), image.getIconHeight());
			}else {
				validity = false;
			}
		}
	}
	public void boom(Plane plane) {//150*150的爆炸半径
		if(isInto(plane.x,plane.y) || isInto(plane.x+plane.width,plane.y) || 
				 isInto(plane.x,plane.y+plane.height) || isInto(plane.x+plane.width,plane.y+plane.height) ) {
				plane.health -= level/2;
			}
			
		
	}

	private boolean isInto(int x,int y) {
		if(x>=this.x-150 && x<=this.x+150) {
			if(y>= (int) -((Math.sqrt(22500-((x-this.x)*(x-this.x))))-this.y) && 
					y<=(int)( 2*this.y-(-((Math.sqrt(22500-((x-this.x)*(x-this.x))))-this.y)))) {
				return true;
				
			}else {

				return false;
			}
		}else {

			return false;
		}
		
	}

}
