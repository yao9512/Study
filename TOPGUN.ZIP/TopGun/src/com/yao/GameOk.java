package com.yao;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GameOk extends JFrame{
	public static int width = Game.width;
	public static int height = Game.height;
	
	public JLabel overLabel = new JLabel("To be Continue....");
	public JLabel score_Label = new JLabel();
	public JLabel text = new JLabel();
	
	public Font font = new Font("幼圆",Font.ITALIC,45);
	public Font font1 = new Font("幼圆",Font.ITALIC,15);
	public Font font2 = new Font("幼圆",Font.ITALIC,25);

	public JButton reset = new JButton("再来一次");
	GameOk(int count){
		this.setLayout(null);
		this.setBounds(450, 100, width, height);
		this.setTitle("TOP GUN");
		this.setDefaultCloseOperation(3);
		overLabel.setBounds(100, 100, 500, 100);
		overLabel.setFont(font);
		score_Label.setText("你一共击落飞机数量："+count);
		score_Label.setFont(font2);
		score_Label.setBounds(150, 200, 300, 60);

		text.setBounds(180, 280, 600, 60);
		text.setText("我与总部彻底失去了联系，地球的命运也岌岌可危.....我该返回还是前进........");
		reset.setBounds(500, 420, 100, 50);
		reset.setFont(font1);
		reset.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				Game newgame = new Game();
			}
		});
		this.add(text);
		this.add(overLabel);
//		this.add(reset);
		this.add(score_Label);
		this.setVisible(true);
		
	}
}
