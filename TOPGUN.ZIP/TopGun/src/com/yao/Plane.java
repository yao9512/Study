package com.yao;

import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public abstract class Plane extends JLabel{
//state 只是状态 可能是虚空状态！！ 就是有血量 但是不可显示
	int x;
	int y;
	int width;
	int height;
	int health;
	int health_tol;
	int level;
	int firepower;
	int speedpower;
	int guns;
	boolean state = false;
	Plane(){
		super();
	}
	
	public abstract void move();
	public abstract boolean impact(Plane plane);

	public abstract boolean fire();
	public abstract void move(boolean up, boolean down, boolean left, boolean right) ;
	public abstract void dead();
	public abstract void ember();
	public abstract boolean isAlive();
}
