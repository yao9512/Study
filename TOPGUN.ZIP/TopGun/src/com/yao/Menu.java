package com.yao;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.swing.*;

public class Menu extends JFrame{

	public static int width = 400;
	public static int height = 500;

	public static BufferedImage pic;

	JButton start_Button = new JButton("Start");
	JLabel title_Label = new JLabel("TOP GUN");
	JLabel intro_Label = new JLabel();

	JLabel intro_Label1 = new JLabel();
	
	Font title_Font = new Font("幼圆",Font.ITALIC,26);
	Font intro_Font = new Font("幼圆",Font.ITALIC,14);



	Menu(String name){
		this.setTitle(name);
		this.setBounds(500, 200, width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setResizable(false);
		
		intro_Label1.setBounds(7, 400, 400, 40);
		intro_Label1.setText("游戏玩法-z:维修 x:高级维修 c:激光导弹 v:核弹 b:天幕 space:开火");
		start_Button.setBounds(150, 250, 80, 30);
		start_Button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				Game newgame = new Game();
			}
		});

		title_Label.setBounds(135, 50, 300, 50);
		title_Label.setFont(title_Font);

		intro_Label.setBounds(30, 330, 300, 100);
		intro_Label.setText("注意：请将输入法切换为英文输入法！");
		intro_Label.setFont(intro_Font);
		
		this.add(intro_Label);
		this.add(title_Label);
		this.add(start_Button);
		this.add(intro_Label1);
	}

	public void run() {
		this.setVisible(true);
	}
}
