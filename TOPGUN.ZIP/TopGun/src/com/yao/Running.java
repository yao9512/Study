package com.yao;

public class Running {
	public static Menu mainMenu = new Menu("TopGun 最终1.0版 By.Yao~");
	
	public static void main(String[] args) {
		mainMenu.run();
	}
}
//输入法英文！！
//2019.8.16		整体程序完成
//2019.8.22		图片加载完成