package com.yao;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;

public class PlayInfo extends JPanel{

	JLabel head2 = new JLabel();
	JLabel head1 = new JLabel();
	JPanel head = new JPanel();
	JPanel cont = new JPanel();	

	volatile int coin;
	volatile int level;
	
	int[] goodprice = 		{20,    80,        80,   120,  100, 200,200,250,250,200,300};
	String[] goodName = {"修理工具","高级修理","导弹","核弹","天幕","机壳等级","引擎等级","机枪射速","多管火炮","子弹射速","火力等级"};
	int goodResult[] =   {2,  			0,				1,			0,			0,0,0,0,0,0,1};; //  num
	//0-repair 1-advanced repair 2-missile 3-nuclear 4-tianmu 5-health 6-speed 7-firerate
	//8-Gun 9-firespeed
	ArrayList<JTextArea> Texts = new ArrayList<>();//我的消息
	ArrayList<JLabel> names = new ArrayList<>();//我的消息
	ArrayList<JLabel> icons = new ArrayList<>();//我的消息
	ArrayList<JButton> goods = new ArrayList<>();
	JButton lottery = new JButton();
	//	ArrayList<ImageIcon> images = new ArrayList<>();//我的消息

	//ImageIcon MyImage = new ImageIcon(PlayInfo.class.getResource("airplane.png"));

	Font font_talk = new Font("文泉驿微米黑", Font.PLAIN, 14);
	Font font_talk1 = new Font("文泉驿微米黑", Font.PLAIN, 12);


	public PlayInfo() {

		this.setBounds(Game.Gamewidth+2, Game.Gameheight/2+2, Game.width-Game.Gamewidth-7, Game.Gameheight/2-2);
		this.setBackground(new Color(230, 230, 230));
		this.setLayout(null);

		head.setLayout(null);
		head.setBounds(0, 0, getWidth(), 25);
		head1.setBounds(1, 1, getWidth(), 25);
		head1.setIcon(new ImageIcon(Enemy.class.getResource("head.png")));
		head.setBorder(BorderFactory.createLineBorder(Color.black));
		head2.setBounds(1, 0, getWidth()-2, 30);
		head2.setIcon(new ImageIcon(Enemy.class.getResource("head2.png")));

		cont.setBounds(0, 20, getWidth(), getHeight()-20);
		cont.setLayout(null);
		cont.setBorder(BorderFactory.createLineBorder(Color.black));
		
		head.add(head1);
		this.add(head);
		this.add(cont);
	}

	public void showAvThing(int cut,int stage) {
		//关闭所有组件！！！
		switch(cut) {
		case 0://一开始
			//气泡 width=158 height=25 
			break;
		case 1:
			closeAll();
			switch(stage) {
			case 0:
				break;
			case 1:
				talk(1,false,"总指挥老李","听着小张，你的任务就是活下去，撑到地球防御军拿到火星能源防"
						+ "御罩密码！届时给他们的远程能源中心给一颗原子弹尝尝！切断他们进攻地球敌机的能量来源。");
				talk(2,true,"王牌飞行员小张","保证完成任务！，长官！！！");
				break;
			case 2:
				talk(1,true,"王牌飞行员小张","@总指挥老李 火星上发生了什么？");
				talk(2,false,"总指挥老李","火星殖民地的军队反叛了组织，想要回到地球推翻地球的领导。");
				break;
			case 3:
				talk(1,false,"总指挥老李","这边火星反叛军快打进来了！能源密钥发给你了，你这边怎么样？");
				talk(2,true,"王牌飞行员小张","@总指挥老李 已经发现敌军远程能源中心");
				break;
			case 4:
				talk(1,true,"王牌飞行员小张","@总指挥老李 为什么能源中心还没有被摧毁？");
				talk(2,false,"总指挥老李","这边敌人的机甲，装甲车能源没有断!怎么回事？");
				break;
			case 5:
				talk(1,false,"总指挥老李","这波似乎是敌人的精英战机，装备点无敌天幕！以备不时之需。");
				talk(2,true,"王牌飞行员小张","@总指挥老李 不知道我顶不顶的住。。。");

				break;
			}
			break;
		case 2:
			closeAll();
			switch(stage) {
			case 0:
				break;
			case 1:
				talk(1,false,"总指挥老李","21世纪最杰出的飞行员，在2359年同样不能懈怠！撑下去。");
				talk(2,false,"管理员小王","未知人员加入了群聊");
				talk(3,false,"****","看我一脚踢烂你们的屁股！蠢货！");
				talk(4,true,"王牌飞行员小张","@**** 随时奉陪！伙计！");
				break;
			case 2:
				talk(1,true,"王牌飞行员小张","敌人一次比一次厉害了！");
				talk(2,false,"管理员小王","未知人员2加入了群聊");
				talk(3,false,"****","又来一个送死的。");
				break;
			case 3:
				talk(1,true,"王牌飞行员小张","就是他！");
				talk(2,false,"管理员小王","未知人员3加入了群聊");
				talk(3,false,"****","守住阵地，休想破坏我们的能源中心！");

				break;
			case 4:
				talk(1,false,"管理员小王","未知人员4加入了群聊");
				talk(2,false,"****","想多了！你们进入了圈套！哈哈！等死吧你们！");
				talk(3,true,"王牌飞行员小张","我雕尼马的！");
				talk(4,false,"总指挥老李","我雕尼马的！");
				break;
			case 5:
				talk(1,false,"总指挥老李","小张！内部有wod klkfmglkfg");
				talk(2,false,"管理员小王","未知人员5加入了群聊");
				talk(3,false,"****","张，加入我们吧，你这种精英，在这屈才了！");
				talk(4,true,"王牌飞行员小张","老李？");

				break;
			}
			break;
		case 3:
			closeAll();
			switch(stage) {
			case 0:
				break;
			case 1:
				talk(1,true,"王牌飞行员小张","@**** 嘿，哥们，你们2359年的武器就这么差劲么？该换换家伙了！哈哈！！");
				talk(2,false,"****","不要嚣张，小子！");
				talk(3,false,"总指挥老李","@管理员小王 哦！上帝！这家伙是怎么黑进来的？");
				break;
			case 2:
				talk(1,false,"总指挥老李","小张，稳住，全村人的希望啊！！");
				talk(2,true,"王牌飞行员小张","敌人火力越来越猛了！");
				break;
			case 3:
				talk(1,false,"总指挥老李","@管理员小王 你明天可以不用来上班了！");
				talk(2,true,"王牌飞行员小张","。。。。");
				talk(3,false,"管理员小王","。。。。正在排查");

				break;
			case 4:
				talk(1,false,"总指挥老李","干死他");
				talk(2,true,"王牌飞行员小张","。。。。");
				break;
			case 5:
				talk(1,true,"王牌飞行员小张","老李？");
				talk(2,true,"王牌飞行员小张","老李？");
				talk(3,true,"王牌飞行员小张","小王？？发生了什么？");
				talk(4,true,"王牌飞行员小张","老李你最后是说内部有卧底么？");

			break;
			}
			break;
		case 4:
			closeAll();

			cont.setLayout(new GridLayout(4, 3, 0, 0));
			for(int i=0;i<goodResult.length;i++) {
				JButton good = new JButton();
				good.setFocusable(false);
				good.setMargin(new Insets(0, 0, 0, 0));
				good.setName(i+"");
				good.setText("<html>"+goodName[i]+"<br>"+goodprice[i]+"美元</html>");
				good.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						if(coin >= goodprice[Integer.parseInt(good.getName())]) {
							if(Integer.parseInt(good.getName()) == 0) {
								if(goodResult[0]>=level) {
									goodResult[0] = level;
								}else {
									goodResult[Integer.parseInt(good.getName())]++;
									coin -= goodprice[Integer.parseInt(good.getName())];
								}
								
							}else {
								if(Integer.parseInt(good.getName())<3) {
									if(goodResult[Integer.parseInt(good.getName())]>=level-1) {
										goodResult[Integer.parseInt(good.getName())] = level-1;
									}else {
										goodResult[Integer.parseInt(good.getName())]++;
										coin -= goodprice[Integer.parseInt(good.getName())];
									}
								}else if(Integer.parseInt(good.getName())<5) {
									if(goodResult[Integer.parseInt(good.getName())]>=level-2) {
										goodResult[Integer.parseInt(good.getName())] = level-2;
									}else {
										goodResult[Integer.parseInt(good.getName())]++;
										coin -= goodprice[Integer.parseInt(good.getName())];
									}
								}else {
									goodResult[Integer.parseInt(good.getName())]++;
									coin -= goodprice[Integer.parseInt(good.getName())];
								}
								
							}
			
						}
						
						
//						if(goodResult[1]>level-1)
//							goodResult[1] = level-1;
//						if(goodResult[2]>level-1)
//							goodResult[2] = level-1;
//						if(goodResult[3]>level-2)
//							goodResult[3] = level-2;
//						if(goodResult[4]>level-2)
//							goodResult[4] = level-2;
						
						if(goodResult[5]>7)
							goodResult[5] = 7;
						if(goodResult[6]>4)
							goodResult[6] = 4;
						if(goodResult[7]>4)
							goodResult[7] = 4;
						if(goodResult[8]>3)
							goodResult[8] = 3;
						if(goodResult[9]>3)
							goodResult[9] = 3;

					}
				});
				goods.add(good);
				cont.add(good);
			}
			
			lottery.setMargin(new Insets(0, 0, 0, 0));
			lottery.setFocusable(false);
			lottery.setText("<html>不中彩票<br>50/100    美元</html>");
			lottery.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					if(coin >= 50) {
						System.out.println(50 );
						coin -=50;
						Random rand = new Random();
						if(rand.nextInt(10)==9) {//10分之1的几率中奖
							coin += 500;
							JOptionPane.showMessageDialog(null, "恭喜你中了不中彩票一等奖500美元！");
						}
					}
				}
			});
			cont.add(lottery);
			
			cont.repaint();
			repaint();

			
			break;
		
		default:
			break;




		}
	}


	private void closeAll() {
		cont.setLayout(null);

		for(int i=0;i<Texts.size();i++) {
			Texts.get(i).setVisible(false);
			icons.get(i).setVisible(false);
			names.get(i).setVisible(false);
		}
		for(int i=0;i<goods.size();i++) {
			goods.get(i).setVisible(false);
		}
		Texts.clear();
		icons.clear();
		names.clear();
		goods.clear();
		head2.setVisible(false);
		cont.removeAll();
		cont.repaint();
		head.repaint();
		repaint();

	}

	private void talk(int num,boolean who,String name,String content) {
		int width_bubble;
		int height_bubble;
		int x;



		head2.setVisible(true);
		cont.add(head2);
		JTextArea label1 = new JTextArea();
		Texts.add(label1);
		Texts.get(0).setBounds(0, 0, 0, head2.getHeight());
		JLabel label2 = new JLabel();
		icons.add(label2);
		icons.get(0).setBounds(0, 0, 0, head2.getHeight());
		JLabel label3 = new JLabel();
		names.add(label3);
		names.get(0).setBounds(0, 0, 0, head2.getHeight());

		if((content.length()*15)/158>0) {
			height_bubble = ((content.length()*15)/158)*18+18;
			width_bubble = 158;
		}else {
			height_bubble = 18;
			width_bubble = content.length()*14;

		}


		JTextArea LabelText = new JTextArea(); 
		JLabel icon = new JLabel(); 
		JLabel Labelname = new JLabel(); 
		names.add(Labelname);
		icons.add(icon);
		Texts.add(LabelText);

		Texts.get(num).setOpaque(true);
		Texts.get(num).setLineWrap(true);
		Texts.get(num).setEditable(false);
		Texts.get(num).setFont(font_talk);
		Texts.get(num).setVisible(true);
		Texts.get(num).setFocusable(false);
		icons.get(num).setFocusable(false);
		names.get(num).setFocusable(false);
		names.get(num).setFont(font_talk1);

		if(who) {//true Me
//			icons.get(num).setBackground(Color.BLACK);
//			icons.get(num).setOpaque(true);
			icons.get(num).setIcon(new ImageIcon(Enemy.class.getResource("me.png")));
			icons.get(num).setBounds(getWidth()-30, Texts.get(num-1).getY()+Texts.get(num-1).getHeight()+5, 20, 20);
			names.get(num).setBounds(getWidth()-30-105,Texts.get(num-1).getY()+Texts.get(num-1).getHeight()+10,100,15);
			names.get(num).setHorizontalAlignment(4);
			x = (icons.get(num).getX()+icons.get(num).getWidth())-width_bubble-3;
			Texts.get(num).setBounds(x, icons.get(num).getY()+icons.get(num).getHeight()+5, width_bubble, height_bubble);
			Texts.get(num).setText(content);
			//		Texts.get(num).setBackground(new Color(128, 226, 40));
			Texts.get(num).setBackground(new Color(158, 234, 106));//原版微信的rgb
			names.get(num).setText(name);
		}else {//false Him

			if(name.equals("总指挥老李")) {
				icons.get(num).setIcon(new ImageIcon(Enemy.class.getResource("commander.png")));

			}else if(name.equals("管理员小王")) {
				icons.get(num).setIcon(new ImageIcon(Enemy.class.getResource("admin.png")));

			}else if(name.equals("****")) {
				icons.get(num).setIcon(new ImageIcon(Enemy.class.getResource("boss.png")));

			}else {
				icons.get(num).setOpaque(true);
				names.get(num).setHorizontalAlignment(2);
			}
			Texts.get(num).setBackground(Color.white);
			icons.get(num).setBounds(10, Texts.get(num-1).getY()+Texts.get(num-1).getHeight()+5, 20, 20);
			icons.get(num).setBackground(Color.BLACK);
			names.get(num).setBounds(35,Texts.get(num-1).getY()+Texts.get(num-1).getHeight()+10,100,15);
			Texts.get(num).setBounds(13, icons.get(num).getY()+icons.get(num).getHeight()+5, width_bubble, height_bubble);
			Texts.get(num).setText(content);
			names.get(num).setText(name);
		}
		cont.add(icons.get(num));
		cont.add(Texts.get(num));
		cont.add(names.get(num));
		cont.repaint();
		repaint();

	}
	//	public int[] getGoods() {
	//		return goodResult;
	//	}

}
