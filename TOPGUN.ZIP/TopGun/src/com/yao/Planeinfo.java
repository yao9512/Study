package com.yao;

import java.awt.Color;
import java.awt.Font;

import javax.swing.*;

public class Planeinfo extends JPanel{
	JLabel title = new JLabel();
	int level;
	Planeinfo(){
		this.setBorder(BorderFactory.createLineBorder(Color.black));
		this.setBounds(Game.Gamewidth+2, 0, Game.width-Game.Gamewidth-7, Game.Gameheight/2);
		Font font = new Font("幼圆", Font.BOLD, 45);
		title.setFont(font);
//		title.setBounds(0, 30, Game.Gamewidth, Game.Gameheight-30);
		
		this.add(title);
	}

}
