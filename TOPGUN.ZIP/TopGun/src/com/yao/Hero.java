package com.yao;

import javax.swing.ImageIcon;

public class Hero extends Plane{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int flyMiles_hero = 1;
	ImageIcon pic1 = new ImageIcon(Enemy.class.getResource("plane2.png"));
	ImageIcon pic2 = new ImageIcon(Enemy.class.getResource("plane1.png"));

	Hero(){
		width = pic1.getIconWidth();
		height = pic1.getIconHeight();
		x = Game.Gamewidth/2-width;
		y = Game.Gameheight/5*4;
		this.setBounds(x, y, width, height);
		this.setIcon(pic1);
		state = true;
		level = 1;
		health_tol = 40;
		health = health_tol;
		firepower = 1;
	}

	public void move(boolean up,boolean down,boolean left,boolean right) {
		if(left == true&&x>0) { //left
			this.x -= flyMiles_hero; 
		}

		if(up == true&&y>0) { //up
			this.y -= flyMiles_hero;
		}
		if(right == true&&x<(Game.Gamewidth-width)) { //right
			this.x += flyMiles_hero;
		}
		if(down == true&&y<(Game.Gameheight-height)) { //down
			this.y += flyMiles_hero;
		}
		


		

		this.setBounds(x, y, width, height);

	}



	@Override
	public void move() {

	}

	@Override
	//英雄 见血 如果没血了 就挂了
	public boolean impact(Plane plane) {

		if((this.x>(plane.x-this.width+10)) && this.x<(plane.x+plane.width-10) &&
			  this.y>(plane.y-this.height+10) && (this.y<(plane.y+plane.height-10))) {

				
				return true;
		}else {
			return false;
		}
	}

	@Override
	public boolean fire() {

		switch(level) {
		case 1:
			
			break;
		case 5:
			break;
			
		case 15:
			break;
		default:
			break;
		}
		return state;
		
		
	}
	public void upgrade() {
		level +=1;
	}

	@Override
	public void dead() {
		this.state = false;
		this.setVisible(false);
	}

	@Override
	public boolean isAlive() {
		if(this.health <= 0 ) {
			return false;
		}else {
			return true;

		}
		
	}

	@Override
	public void ember() {
		// TODO Auto-generated method stub
		
	}

}
