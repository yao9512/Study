package com.yao;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;


public class Enemy extends Plane {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ImageIcon pic1 = new ImageIcon(Enemy.class.getResource("airplane.png"));
	ImageIcon pics[] = new ImageIcon[4];

	public int flyMiles_enemy = 1;
	public volatile int embercount = 0;
	
	Enemy(int type_Enemy){
		this.health = type_Enemy;
		this.health_tol = type_Enemy;
		this.state = false;
		level = type_Enemy;
		this.setIcon(pic1);
		for(int i=0;i<4;i++) {
			pics[i] = new ImageIcon(Enemy.class.getResource("airplane_ember"+i+".png"));
		}

	}


	@Override
	public void move() {
		if(this.state) {

			if(this.y<Game.Gameheight) {
				if(health>=0) {
					this.y += flyMiles_enemy;

				}else {//embering
					
				}
			}else {
				this.state = false;
			}
			this.setBounds(x, y, width, height);

		}else {

		}


	}


	public void rebornEnemy(int stage) {

		Random rand = new Random();
		Random rand2 = new Random();

		this.setVisible(true);
		this.width = (level*2)+pic1.getIconWidth();
		this.height = (level*2)+pic1.getIconHeight();
		this.x = rand.nextInt(Game.Gamewidth-this.width)+(this.width/2);
		this.y = 0-rand2.nextInt(Game.height);
		this.setBounds(x, y, width, height);
		Random rand1 = new Random();
		level = rand1.nextInt(stage+4)+1;
		health = level;
		this.setIcon(pic1);
	}




	@Override
	public void move(boolean up, boolean down, boolean left, boolean right) {
		// TODO Auto-generated method stub

	}


	@Override
	public boolean impact(Plane plane) {
		return false;
	}


	@Override
	public boolean fire() {
		// TODO Auto-generated method stub
		return false;
	}
	public void dead() {
		this.state = false;
		this.setVisible(false);
		this.x = 0;
		this.y = Game.Gameheight;
	}


	@Override
	public boolean isAlive() {
		if((!this.state) && (this.health<=0)) {
			return false;
		}else {
			return true;

		}		
	}


	@Override
	public void ember() {
		embercount++;
		if(embercount%7 == 0) {
			this.setIcon(pics[embercount/10]);
		}
		if(embercount == 21) {
			this.dead();
			this.state = false;
			embercount = 0;
		}
	}
}
