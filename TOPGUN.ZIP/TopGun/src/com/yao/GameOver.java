package com.yao;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GameOver extends JFrame{
	public static int width = Game.width;
	public static int height = Game.height;
	
	public JLabel overLabel = new JLabel("GameOver");
	public JLabel score_Label = new JLabel();

	public Font font = new Font("幼圆",Font.ITALIC,45);
	public Font font1 = new Font("幼圆",Font.ITALIC,15);
	public Font font2 = new Font("幼圆",Font.ITALIC,25);

	public JButton reset = new JButton("再来一次");
	GameOver(int count){
		this.setLayout(null);
		this.setBounds(450, 100, width, height);
		this.setTitle("TOP GUN");
		this.setDefaultCloseOperation(3);
		overLabel.setBounds(250, 180, 300, 100);
		overLabel.setFont(font);
		score_Label.setText("击落飞机数量："+count);
		score_Label.setFont(font2);
		score_Label.setBounds(80, 300, 300, 60);

		reset.setBounds(350, 450, 100, 50);
		reset.setFont(font1);
		reset.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				Game newgame = new Game();
			}
		});
		this.add(overLabel);
		this.add(reset);
		this.add(score_Label);
		this.setVisible(true);
		
	}
}
