package com.yao;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class PanelGame extends JPanel{
	private static BufferedImage image;
	private static BufferedImage image2;

	int y;
	int y1;
	PanelGame(){
		y1 = -1000;
		try {
			image = ImageIO.read(Game.class.getResource("background.png"));
			image2 = ImageIO.read(Game.class.getResource("background.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponents(g);
			g.drawImage(image,0,y,1000,1000,this);
			g.drawImage(image2,0,y1,1000,1000,this);
			repaint();

	}
}
