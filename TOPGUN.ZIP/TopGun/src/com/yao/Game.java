package com.yao;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.GroupLayout.Alignment;



public class Game extends JFrame{


	//游戏界面
	public static int Gamewidth = 500;
	public static int Gameheight = 660;
	//总体界面
	public static int width = 700;
	public static int height = 700;
	public static int time_base = 20;
	private int coin = 0;
	private int score = 0;
	private int count = 0;//击落飞机数
	private int stage = 1;
	//时间属性
	public int Time_Enemy = 13;
	public int Time_Boss = 20;
	public int Time_end = 3;
	public int Time_shop = 15;
	//英雄属性
	public static int fireRate = 450;
	public static int fireSpeed = 4;
	public int time_tianmu;//tianmu time

	//敌机属性
	public static int enemy_num = 25;
	public static int GenTiem = 400;//敌机与敌机之间重生延迟的时间基数
	//boss属性
	private int firerate_boss = 1200;
	private int firespeed_boss = 10;


	//0-repair 1-advanced repair 2-missile 3-nuclear 4-tianmu 5-health 6-speed 7-firerate
	//8-Gun 9-firespeed

	private PanelGame panelGame= new PanelGame();
	private JLabel score_JLabel = new JLabel();
	private JLabel Pause_JLabel = new JLabel();
	private Font pause_Font = new Font("黑体",Font.BOLD,62);
	private Font level_Font = new Font("黑体",Font.BOLD,20);
	private JLabel tianmuTime = new JLabel();

	private JLabel health_Tol = new JLabel();
	private JLabel health_Now = new JLabel();
	private JLabel bossHealth_Tol = new JLabel();
	private JLabel bossHealth_Now = new JLabel();

	private JLabel Hp = new JLabel("生命值");
	private JLabel level_JLabel = new JLabel();
	private JLabel Time_JLabel = new JLabel();
	private JLabel StageName = new JLabel();
	private JLabel coinJLabel = new JLabel();
	private JLabel repairStuff = new JLabel();
	private JLabel quickRepairStuff = new JLabel();
	private JLabel missile = new JLabel();
	private JLabel nuclear = new JLabel();
	private JLabel tianmu = new JLabel();
	private JLabel repairStuff1 = new JLabel();
	private JLabel quickRepairStuff1 = new JLabel();
	private JLabel missile1 = new JLabel();
	private JLabel nuclear1 = new JLabel();
	private JLabel tianmu1 = new JLabel();
	private JLabel[] planelevel = new JLabel[6];


	//public int bulletsLeft = 0;//弹药剩余量
	//public int bulletsUsed = 0;//弹药真正用完的数量
	private boolean up = false;
	private boolean down = false;
	private boolean left = false;
	private boolean right = false;
	private boolean tianmuFlag = false;
	volatile int time = 0;//关卡的剩余时间+飞机停止生成时间+商店时间
	volatile boolean fire = false; //volatile 很重要 没有他 后面的run函数里运行不了！！
	volatile boolean fire_boss = false;
	volatile boolean runningState = false;
	volatile boolean game_Run = true; //when you die, the clock stops to tick.real stop
	volatile boolean GenEnemyState = true;
	volatile int infoNum = 1;//控制有下角现实内容


	volatile Enemy enemy[]= new Enemy[enemy_num];
	ArrayList<Bullet> bullets_Boss = new ArrayList<>();
	ArrayList<Bullet> bullets = new ArrayList<>();
	ArrayList<JLabel> missileFlash = new ArrayList<>();
	ImageIcon image_missile = new ImageIcon(Game.class.getResource("missile.png"));

	Bullet missile_bullet = new Bullet();
	Hero hero = new Hero();
	Boss boss = new Boss(stage);;
	PlayInfo playinfo = new PlayInfo();
	Planeinfo planeinfo = new Planeinfo();

	Thread thread_Hero;
	MoveThread move_Thread_hero= new MoveThread();

	Thread thread_Enemy;
	enemyMove move_Thread_enemy = new enemyMove();

	Thread thread_GenEnemy;
	GenEnemy Gen_Thread_enemy= new GenEnemy();

	Thread thread_Fire;
	FireHero Fire_Thread_hero= new FireHero();

	Thread thread_Bullet;
	BulletMove Move_Thread_bullet= new BulletMove();

	Thread thread_Stage;
	StageThread stage_Thread_game= new StageThread();

	Thread thread_Boss;
	BossThread move_Thread_boss= new BossThread();

	Thread thread_BossFire;
	BossFireThread fire_Thread_boss= new BossFireThread();

	Thread thread_BossBullet;
	BossBulletMoveThread bulletMove_Thread_boss= new BossBulletMoveThread();



	Game(){
		runningState = true;
		playinfo.showAvThing(infoNum,stage);
		panelGame.setFocusable(true);
		playinfo.setFocusable(true);
		planeinfo.setFocusable(true);
		missile_bullet.validity = false;

		this.setResizable(false);
		this.setLayout(null);
		this.setBounds(450, 100, width, height);
		this.setTitle("TOP GUN 最终1.0版 By.Yao~");
		this.setDefaultCloseOperation(3);



	
		missile_bullet.setSize(image_missile.getIconWidth(), image_missile.getIconHeight());
		missile_bullet.setIcon(image_missile);

		tianmuTime.setSize(10,10);
		tianmuTime.setVisible(false);

		panelGame.setBounds(0, 0, Gamewidth, Gameheight);
		panelGame.setLayout(null);
		panelGame.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		planeinfo.setLayout(null);
		playinfo.setLayout(null);

		Hp.setBounds(10, 5, 100, 15);
		bossHealth_Tol.setBounds(10,10,boss.health_tol,15);
		bossHealth_Tol.setOpaque(false);
		bossHealth_Tol.setVisible(false);

		bossHealth_Tol.setBackground(Color.red);
		bossHealth_Tol.setBorder(BorderFactory.createLineBorder(Color.black));
		bossHealth_Now.setBounds(10,10,boss.health,15);
		bossHealth_Now.setOpaque(true);
		bossHealth_Now.setBackground(Color.red);
		bossHealth_Now.setVisible(false);

		health_Tol.setBounds(10,24,hero.health_tol,15);
		health_Tol.setOpaque(false);
		health_Tol.setBackground(Color.red);
		health_Tol.setBorder(BorderFactory.createLineBorder(Color.black));
		health_Now.setBounds(10,24,hero.health,15);
		health_Now.setOpaque(true);
		health_Now.setBackground(Color.red);

		score_JLabel.setBounds(10, 50, 150, 15 );
		score_JLabel.setText("经验： "+score+"/"+30);
		level_JLabel.setBounds(130, 30, 70, 50);
		level_JLabel.setText(hero.level+" 级");
		level_JLabel.setFont(level_Font);
		level_JLabel.setHorizontalAlignment(JLabel.CENTER);

		coinJLabel.setBounds(10, 75, 150, 15);
		coinJLabel.setText("金币： "+coin+" 美元");

		repairStuff.setBounds(10, 95, 40, 40);
		repairStuff.setOpaque(true);
		repairStuff.setBackground(Color.red);
		repairStuff.setText("<html>&nbsp普通<br> &nbsp修理</html>");
		repairStuff.setForeground(Color.white);
		repairStuff1.setBounds(10, 138, 40, 8);
		repairStuff1.setHorizontalAlignment(JLabel.CENTER);


		quickRepairStuff.setBounds(70, 95, 40, 40);
		quickRepairStuff.setOpaque(true);
		quickRepairStuff.setBackground(Color.red);
		quickRepairStuff.setText("<html>&nbsp高级<br> &nbsp修理</html>");
		quickRepairStuff.setForeground(Color.white);
		quickRepairStuff1.setBounds(70, 138, 40, 10);
		quickRepairStuff1.setHorizontalAlignment(JLabel.CENTER);

		missile.setBounds(130, 95, 40, 40);
		missile.setOpaque(true);
		missile.setBackground(Color.red);
		missile.setText("<html>&nbsp激光<br> &nbsp导弹</html>");
		missile.setForeground(Color.white);
		missile1.setBounds(130, 138, 40, 10);
		missile1.setHorizontalAlignment(JLabel.CENTER);

		nuclear.setBounds(10, 150, 40, 40);
		nuclear.setOpaque(true);
		nuclear.setBackground(Color.red);
		nuclear.setText("<html>&nbsp末世<br> &nbsp核弹</html>");
		nuclear.setForeground(Color.white);
		nuclear1.setBounds(10, 192, 40, 10);
		nuclear1.setHorizontalAlignment(JLabel.CENTER);

		tianmu.setBounds(70, 150, 40, 40);
		tianmu.setOpaque(true);
		tianmu.setBackground(Color.red);
		tianmu.setText("<html>&nbsp无敌<br> &nbsp天幕</html>");
		tianmu.setForeground(Color.white);
		tianmu1.setBounds(70, 192, 40, 10);
		tianmu1.setHorizontalAlignment(JLabel.CENTER);

		for(int i=0;i<planelevel.length;i++) {
			planelevel[i] = new JLabel();
			planelevel[i].setBounds(40, 210+(i*16), 180, 13);
			planeinfo.add(planelevel[i]);
		}

		Time_JLabel.setBounds(100, planeinfo.getHeight()-25, 150, 20);
		StageName.setBounds(10,planeinfo.getHeight()-25,120,20);
		StageName.setText("第"+stage+"关");

		Pause_JLabel.setBounds(170, 250, 300, 80);
		Pause_JLabel.setText("Pause");
		Pause_JLabel.setFont(pause_Font);
		Pause_JLabel.setForeground(Color.BLUE);
		Pause_JLabel.setVisible(false);




		for(int i=0;i<enemy_num;i++) {
			enemy[i] = new Enemy(new Random().nextInt(3)+stage);
			panelGame.add(enemy[i]);
		}

		panelGame.add(bossHealth_Tol);
		panelGame.add(bossHealth_Now);
		panelGame.add(Pause_JLabel);
		panelGame.add(hero);
		panelGame.add(boss);
		panelGame.add(tianmuTime);


		panelGame.add(missile_bullet);
		planeinfo.add(Time_JLabel);
		planeinfo.add(Hp);
		planeinfo.add(score_JLabel);
		planeinfo.add(health_Tol);
		planeinfo.add(health_Now);
		planeinfo.add(level_JLabel);
		planeinfo.add(StageName);
		planeinfo.add(coinJLabel);
		planeinfo.add(repairStuff);
		planeinfo.add(quickRepairStuff);
		planeinfo.add(missile);
		planeinfo.add(nuclear);
		planeinfo.add(tianmu);
		planeinfo.add(repairStuff1);
		planeinfo.add(quickRepairStuff1);
		planeinfo.add(missile1);
		planeinfo.add(nuclear1);
		planeinfo.add(tianmu1);

		this.getContentPane().add(panelGame);
		this.getContentPane().add(playinfo);
		this.getContentPane().add(planeinfo);

		thread_Hero = new Thread(move_Thread_hero);//创建英雄按键扫描线程
		thread_Enemy = new Thread(move_Thread_enemy);//创建敌机移动扫描线程
		thread_GenEnemy = new Thread(Gen_Thread_enemy);//创建敌机生成扫描线程
		thread_Fire = new Thread(Fire_Thread_hero);//创建英雄开火生成弹药扫描线程
		thread_Bullet = new Thread(Move_Thread_bullet);//创建弹药飞行扫描线程
		thread_Stage = new Thread(stage_Thread_game);//+关卡计时
		thread_Boss = new Thread(move_Thread_boss);//+boss飞行
		thread_BossBullet = new Thread(bulletMove_Thread_boss);//boss子弹飞行
		thread_BossFire = new Thread(fire_Thread_boss);//+boss子弹生成

		thread_GenEnemy.start();
		thread_Enemy.start();
		thread_Hero.start();
		thread_Fire.start();
		thread_Bullet.start();
		thread_Stage.start();
		thread_Boss.start();
		thread_BossBullet.start();
		thread_BossFire.start();
		panelGame.addKeyListener(new KeyListener() {

			@Override
			public void keyPressed(KeyEvent e) {
				switch (e.getKeyCode()) {
				case 27:
					runningState = !runningState;
					if(runningState) {
						Pause_JLabel.setVisible(false);
					}else {
						Pause_JLabel.setVisible(true);

					}
					break;

				case 32:
					fire = true;
					break;
				case 37:
					left = true;
					break;
				case 38:
					up = true;
					break;
				case 39:
					right = true;
					break;
				case 40:
					down = true;
					break;
				case 90://z repair
					if(playinfo.goodResult[0]>0 && hero.health_tol>hero.health) {
						if(hero.health_tol-hero.health<=10) {
							hero.health = hero.health_tol;
						}else {
							hero.health += 10;
						}
						playinfo.goodResult[0]--;
					}
					break;
				case 77://后门
					coin += 200;
					break;
				case 88://x qucik repair
					if(playinfo.goodResult[1]>0 && hero.health_tol>hero.health) {
						hero.health = hero.health_tol;
						playinfo.goodResult[1]--;
					}
					break;
				case 67://c missle
					if(playinfo.goodResult[2]>0) {
						if(!missile_bullet.validity) {
							missile_bullet.level = 100;
							missile_bullet.x = hero.x+(hero.width/2);
							missile_bullet.y = hero.y;
							playinfo.goodResult[2]--;
							missile_bullet.validity = true;
						}

					}
					break;
				case 86://v nuclear
					if(playinfo.goodResult[3]>0) {
						for(int i=0;i<enemy_num;i++) {
							if(enemy[i].health>0) {
								enemy[i].health = 0;
								scoreUpdate(enemy[i]);
							}
						}
						if(boss.health > 0) {
							boss.health = 0;
						}
						playinfo.goodResult[3]--;
					}
					break;
				case 66://b tianmu

					if(playinfo.goodResult[4]>0) {
						time_tianmu = 0;
						tianmuFlag = true;
						playinfo.goodResult[4]--;
					}
					break;
				default:
					break;
				}






			}

			@Override
			public void keyTyped(KeyEvent e) {
			}

			@Override
			public void keyReleased(KeyEvent e) {
				switch (e.getKeyCode()) {
				case 32:
					fire = false;

					break;
				case 37:
					left = false;
					break;
				case 38:
					up = false;

					break;
				case 39:
					right = false;

					break;
				case 40:
					down = false;

					break;
				default:
					break;
				}


			}
		});
		this.setVisible(true);

	}



	//英雄的移动线程  检测英雄与boss，小飞机的碰撞
	class MoveThread implements Runnable{
		public MoveThread() {
		}

		@Override
		public void run() {//hero -> move  dead?
			while(game_Run) {
				if(runningState) {
					try {
						if(boss.health <= 0 && boss.state) {
							boss.ember();
						}
						hero.move(up,down,left,right);

						if(hero.impact(boss)) {
							if(!tianmuFlag) {
								hero.health -= (boss.level);
							}
							boss.health -= hero.level*10;//自杀式撞击的伤害
						}
						missile_bullet.move(true);

						for(int i=0;i<enemy_num;i++) {
							if(hero.impact(enemy[i]) ) {
								if(!tianmuFlag) {
									if(enemy[i].health>0)
										hero.health -= enemy[i].level+10;
								}
								enemy[i].health = 0;
							}

							if(missile_bullet.validity && !missile_bullet.explode) {
								if(missile_bullet.isHitted(enemy[i], true)) {
									missile_bullet.explode = true;
								}
							}

							if(enemy[i].embercount == 11) {
								scoreUpdate(enemy[i]);
							}
							//重新布置血量 自己碰到飞机
						}
						if(missile_bullet.isHitted(boss, true)) {
							missile_bullet.explode = true;
						}
						if(missile_bullet.explode && !missile_bullet.validity && missile_bullet.embercount<=40) {
							missile_bullet.embercount++;
							for(int j=0;j<enemy.length;j++) {
								missile_bullet.boom(enemy[j]);
							}
							missile_bullet.boom(boss);
							if(missile_bullet.embercount >=40) {
								missile_bullet.explode = false;
								for(int i=0;i<missileFlash.size();i++){
									missileFlash.get(i).setVisible(false);
								}
								missileFlash.clear();
								missile_bullet.x = -100;
								missile_bullet.y = -100;
								missile_bullet.embercount=0;
							}

							//导弹试验！！
							if(missile_bullet.embercount == 1) {
								for(int i=missile_bullet.x-150;i<missile_bullet.x+150;i++) {
									if(i%2 == 0) {
										JLabel j2 = new JLabel();
										j2.setOpaque(true);
										j2.setBackground(Color.blue);
										j2.setBounds(i, (int) -((Math.sqrt(22500-((i-missile_bullet.x)*(i-missile_bullet.x))))-missile_bullet.y), 2, 2);
										JLabel j1 = new JLabel();
										j1.setOpaque(true);
										j1.setBackground(Color.red);
										j1.setBounds(i, (int)( 2*missile_bullet.y-(-((Math.sqrt(22500-((i-missile_bullet.x)*(i-missile_bullet.x))))-missile_bullet.y))), 2, 2);
										missileFlash.add(j1);
										missileFlash.add(j2);
										panelGame.add(j1);
										panelGame.add(j2);
									}
								}
							}

						}else {

						}
						if(!missile_bullet.explode && !missile_bullet.validity){
							missile_bullet.setLocation(0, -100);
						}
						if(!hero.isAlive()) {
							hero.dead();
						}
						if(boss.embercount == 11) {
							scoreUpdate(boss);
						}
						if(!boss.isAlive()) {
							boss.dead();
						}
						health_Now.setSize(hero.health,15);
						Thread.sleep(time_base);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}
	}
	//小怪的移动线程
	class enemyMove implements Runnable{

		@Override
		public void run() {
			while(game_Run) {
				if(runningState) {
					try {
						for(int i=0;i<enemy_num;i++) {
							enemy[i].move();
							if(enemy[i].health <= 0 && enemy[i].state) {
								enemy[i].ember();
							}
						}
						Thread.sleep(time_base+10);

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}

			}
		}

	}

	//小怪 生成线程
	class GenEnemy implements Runnable {
		int enemyNum = 0;
		int enemy_GenTime[] = new int[enemy_num];
		//		boolean flag_ReadytoGen[] = new boolean[8];
		@Override
		public void run() {
			while(game_Run) {
				if(runningState) {
					if(GenEnemyState) {
						for(int i=0;i<enemy_num;i++) {
							if(enemy[i].state == false) {
								//直接生成xy都不同的敌机
								enemy[i].rebornEnemy(stage);
								enemy[i].state = true;
								enemy[i].flyMiles_enemy = stage/3+1;
								//随机时间不同时间去生成y坐标相同 x坐标不同的敌机
								//								if(enemy_GenTime[i]==0) {
								//									enemy[i].state = true;
								//									enemy[i].rebornEnemy();
								//									enemy_GenTime[i] = new Random().nextInt(GenTiem);
								//								}else {
								//									enemy_GenTime[i]--;
								//								}
							}
						}

					}

					try {
						Thread.sleep(time_base);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}

	}
	class FireHero implements Runnable{//控制bullets生成与销毁
		Bullet bullet1;
		Bullet bullet2;
		Bullet bullet3;
		Bullet bullet4;
		Bullet bullet5;
		@Override
		public void run() {
			while(game_Run) {   
				if(runningState) {
					if(fire && hero.state) {
						switch (playinfo.goodResult[8]) {
						case 0:
							bullet1 = new Bullet(hero.x+(hero.width/2),hero.y,hero.firepower,true);
							bullets.add(bullet1);
							panelGame.add(bullet1);
							break;

						case 1:
							bullet1 = new Bullet(hero.x+(hero.width/3),hero.y,hero.firepower,true);
							bullet2 = new Bullet(hero.x+(hero.width/3*2),hero.y,hero.firepower,true);
							bullets.add(bullet1);
							bullets.add(bullet2);
							panelGame.add(bullet1);
							panelGame.add(bullet2);
							break;
						case 2:
							bullet1 = new Bullet(hero.x+(hero.width/2),hero.y,hero.firepower,true);
							bullet2 = new Bullet(hero.x+(hero.width/4),hero.y,hero.firepower,true);
							bullet3 = new Bullet(hero.x+(hero.width/4*3),hero.y,hero.firepower,true);

							bullets.add(bullet1);
							panelGame.add(bullet1);
							bullets.add(bullet2);
							panelGame.add(bullet2);
							bullets.add(bullet3);
							panelGame.add(bullet3);
							break;
						case 3:
							bullet1 = new Bullet(hero.x+(hero.width/2),hero.y,hero.firepower,true);
							bullet2 = new Bullet(hero.x+(hero.width/6*2),hero.y,hero.firepower,true);
							bullet3 = new Bullet(hero.x+(hero.width/6),hero.y,hero.firepower,true);
							bullet4 = new Bullet(hero.x+(hero.width/6*5),hero.y,hero.firepower,true);
							bullet5 = new Bullet(hero.x+(hero.width/6*4),hero.y,hero.firepower,true);

							bullets.add(bullet1);
							panelGame.add(bullet1);
							bullets.add(bullet2);
							panelGame.add(bullet2);
							bullets.add(bullet3);
							panelGame.add(bullet3);
							bullets.add(bullet4);
							panelGame.add(bullet4);
							bullets.add(bullet5);
							panelGame.add(bullet5);
							break;

						default:
							break;
						}

						try {
							Thread.sleep(fireRate-(100*playinfo.goodResult[7]));
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}

				}

			}

		}

	}
	//子弹的移动线程
	class BulletMove implements Runnable{

		@Override
		public void run() {
			while(game_Run) {
				if(runningState) {
					for(int i=0;i<bullets.size();i++) {
						if(bullets.get(i).validity) {
							bullets.get(i).move(true);
							if(bullets.get(i).isHitted(boss,!tianmuFlag)) {
								if(!boss.isAlive()) {
									boss.dead();
									scoreUpdate(boss);
									infoNum = 4;
								}
							}
							for(int j=0;j<enemy.length;j++) {

								if(bullets.get(i).isHitted(enemy[j],!tianmuFlag)) {
									if(!enemy[j].isAlive()) {
										enemy[j].dead();
									}

								}
							}
						}else {
							bullets.get(i).setVisible(false);
							bullets.remove(i);
						}


					}


					try {
						Thread.sleep(fireSpeed - playinfo.goodResult[9]);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}

	}

	//boss的移动
	class BossThread implements Runnable{

		@Override
		public void run() {
			while(game_Run) {
				if(runningState) {
					if(time >= Time_end+Time_Enemy && time <=Time_end+Time_Enemy+Time_Boss) {

						boss.move();

					}


					try {
						Thread.sleep(time_base+100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}


		}

	}
	//boss 的开火子弹生成 子弹数量=stage*10
	class BossFireThread implements Runnable{
		int firetime = 0;
		@Override
		public void run() {
			while(game_Run) {
				if(runningState) {
					if(boss.state) {
						if(firetime<6+(stage*2)) {//子弹生成数量
							Bullet bullet = new Bullet(boss.x+(hero.width/2),boss.y,boss.level/2+5,false);
							bullets_Boss.add(bullet);
							panelGame.add(bullet);
						}else if(firetime>8){//打完子弹 空闲时间
							firetime = 0;
						}
						firetime++;
					}
				}
				try {
					Thread.sleep(firerate_boss-boss.level*2);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}
	//boss子弹移动
	class BossBulletMoveThread implements Runnable{

		@Override
		public void run() {
			while(game_Run) {
				if(runningState) {
					//if(boss.state) {
					for(int i=0;i<bullets_Boss.size();i++) {
						if(bullets_Boss.get(i).validity) {
							bullets_Boss.get(i).move(false);
							if(bullets_Boss.get(i).isHitted(hero,!tianmuFlag)) {
								//boss子弹打倒自己
								health_Now.setSize(hero.health,15);
								if(!hero.isAlive()) {
									hero.dead();
									break;


								}

							}


						}else {
							bullets_Boss.get(i).setVisible(false);
							bullets_Boss.remove(i);
						}
					}			
					//}
				}
				try {
					Thread.sleep(firespeed_boss-(boss.level/10/2));
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}


		}

	}
	//总县城
	class StageThread implements Runnable{
		int time_temp = Time_Enemy;
		int ms = 0;
		@Override
		public void run() {

			try {
				while(game_Run) {
					if(runningState) {
						if(time == Time_Enemy && ms == 0) {
							infoNum = 2;
							playinfo.showAvThing(infoNum,stage);
							time_temp = Time_Enemy+Time_end;
							GenEnemyState = false;
							StageName.setText("第"+stage+"关：");
						}
						if(time == Time_end+Time_Enemy && ms == 0) {
							infoNum = 3;
							playinfo.showAvThing(infoNum,stage);
							ImageIcon picboss = new ImageIcon(Enemy.class.getResource("boss"+stage+".png"));
							StageName.setText("第"+stage+"关Boss：");
							time_temp = Time_Boss+Time_Enemy+Time_end;
							boss.level = stage*10;
							boss.health_tol = boss.level/2+10;
							boss.health = boss.health_tol;
							boss.state = true;
							boss.setIcon(picboss);
							boss.width = picboss.getIconWidth();
							boss.height = picboss.getIconHeight();
							boss.x = 200;
							boss.y = -boss.height;
							boss.direction = (int)Math.random()*7+9;
							boss.setVisible(true);
							bossHealth_Now.setVisible(true);
							bossHealth_Tol.setVisible(true);
						}
						if(time == Time_Boss+Time_Enemy+Time_end && ms == 0) {
							playinfo.level = hero.level;
							boss.x = boss.width*15;;
							boss.y = -boss.height*2;
							infoNum = 4;
							playinfo.showAvThing(infoNum,stage);
							StageName.setText("商店时间：");
							time_temp = Time_Boss+Time_Enemy+Time_end+Time_shop;
							boss.state = false;
							boss.setVisible(false);
							bossHealth_Now.setVisible(false);
							bossHealth_Tol.setVisible(false);
						}
						if(time>Time_Boss+Time_Enemy+Time_end && time<Time_Boss+Time_Enemy+Time_end+Time_shop) {
							coin = playinfo.coin;
						}
						if(time >= Time_Boss+Time_Enemy+Time_end+Time_shop && ms == 0) {//商店时间过了重新开始

							time_temp = Time_Enemy;
							infoNum = 1;
							playinfo.showAvThing(infoNum,stage+1);
							GenEnemyState = true;
							time = -1;
							stage +=1;
							StageName.setText("第"+stage+"关：");

						}

						//每0.1秒(刷新一次)判断一次游戏是否结束
						if(!hero.isAlive() && game_Run) {
							game_Run = false;
							dispose();
							GameOver gameover = new GameOver(count);
						}

						//物品刷新
						repairStuff1.setText("Z :"+Integer.toString(playinfo.goodResult[0]));
						quickRepairStuff1.setText("X :"+Integer.toString(playinfo.goodResult[1]));
						missile1.setText("C :"+Integer.toString(playinfo.goodResult[2]));
						nuclear1.setText("V :"+Integer.toString(playinfo.goodResult[3]));
						tianmu1.setText("B :"+Integer.toString(playinfo.goodResult[4]));
						//
						bossHealth_Now.setBounds(10,10,boss.health*5,15);
						bossHealth_Tol.setBounds(10,10,boss.health_tol*5,15);

						hero.health_tol = playinfo.goodResult[5]*20+40;
						health_Tol.setBounds(10, 24, hero.health_tol, 15);
						hero.flyMiles_hero = playinfo.goodResult[6]+1;
						coinJLabel.setText("金币： "+coin+" 美元");
						hero.firepower = playinfo.goodResult[10];
						boss.flyMiles_boss = stage*2-1;

						//
						for(int i=0;i<6;i++) {
							planelevel[i].setText(playinfo.goodName[i+5]+" ： Lv "+playinfo.goodResult[i+5]);
						}




						infoNum = 0;
						ms++;

						if(tianmuFlag) {
							tianmuTime.setVisible(true);
							tianmuTime.setLocation(hero.x+hero.width, hero.y+hero.height);
							tianmuTime.setText((9-time_tianmu)+"");
							tianmuTime.setForeground(Color.white);
						}else {
							tianmuTime.setVisible(false);
						}
						if(ms == 50) {//秒函数
							time++;
							ms = 0;
							Time_JLabel.setText("剩余时间："+Integer.toString((time_temp-time)));
							if(tianmuFlag) {
								time_tianmu++;
								if(time_tianmu >= 10) {
									tianmuFlag = false;
									time_tianmu = 0;
								}
							}

						}
//						if(ms == 30) {
							panelGame.y+=12 ;
							panelGame.y1+=12;
							if(panelGame.y>=1000) {
								panelGame.y=-1000;
							}
							if(panelGame.y1>=1000) {
								panelGame.y1=-1000;
							}
//						}
							if(ms%15 == 0) {
								hero.setIcon(hero.pic1);
							}
							if(ms%5 == 0 && ms%15 != 0) {
								hero.setIcon(hero.pic2
										);

							}

							if(stage == 7) {
								dispose();
								GameOk ok = new GameOk(count);
							}
					}

					Thread.sleep(time_base);
				}


			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}



	private void scoreUpdate(Plane enemy) {//打倒敌人时触发
		score += enemy.level; 
		coin += enemy.level+(int)(Math.random()*10);
		playinfo.coin = coin;
		int socretoup = 10*((hero.level+1)*(hero.level+1)-(hero.level+1)+1);
		//upgrade
		if(score>=socretoup) { //n^2-n+1
			hero.level++;
			hero.health = hero.health_tol;

			//老版本 升级 加血 加速度 新版本 只加血
			//health
			//			health_Tol.setBounds(180,0,(level-1)*5+40,20);
			//			health_Now.setBounds(180,0,(level-1)*5+40,20);
			//			hero.health = (level-1)*5+40;
			//speed
			//			if(speed_hero>=7) {
			//				speed_hero -=6;
			//
			//			}else if(speed_hero>1) {
			//				speed_hero = 1;
			//			}

		}
		count += 1;
		socretoup = 10*((hero.level+1)*(hero.level+1)-(hero.level+1)+1);//level更新了需要重新计算
		score_JLabel.setText("经验： "+score+"/"+socretoup);
		level_JLabel.setText(hero.level + " 级");
		coinJLabel.setText("金币： "+coin+" 美元");
	}
}
/*
 * 遗留问题：
 * 1.卡顿问题！当你不在界面内进行任何操作时，会越来越卡，当在界面内滑鼠标时，会不卡，需要解决！
 * 2.敌机一开始的生成问题，不会随机随时生成，只会随地同时生成！但到也增加了乐趣
 * 
 * 
 * 难点1.：控制hero的问题：
 * 当你连续控制飞机的飞行时，有一个开始延迟的问题，就相当于在文本框连续打字的开始延迟。
 * 解决办法：使用一个thread，类被实例化后，开始运行线程，根据上下左右的值来不断调整方向，
 * 					也就是一按下方向键，飞机马上开始连续飞行，直到按键抬起，方向参数变为false，
 * 					线程依旧运行，但是参数不是飞行参数。
 * 
 * 难点2！！：随即生成飞机的方法！！：
 * 还是使用线程，使用一个关键变量state来存储飞机的是否有效（坠毁或是飞出界外），一开始，
 * 控制所有敌方飞机的thread开始运作，但是state是false。在重生飞机的thread中，state是
 * false，这时开始所有的飞机一块生成，（技术有限无法一开始就随即生成，算法结构问题），
 * 这时，state为true，飞机移动thread开始运作，在重生thread中不运作。直到他出了画面或
 * 坠毁，这时重生倒计时可以初始化，然后每次while循化中都会减一次（sleep 规定时间）。每个
 * 地方飞机都有一个state和他的重生时间。
 * 
 *难点3！！：子弹的生成方式和运行逻辑思维
 *分两部分1子弹的不断生成Thread！！2子弹的飞行Thread
 *使用Arrayist来存储不断new出来的Bullet对象，在飞行期间，判断子弹的有效性，一旦失效（
 *飞出视野或是集中目标）就让这个元素对象remove！这样可以一直让子弹源源不断！！不用担心
 *内存溢出！其他和敌方飞机一样！按下thread即开始，抬起结束，取消连按延迟！
 *第二版本：就是有弹匣这个概念 之后完善 先做无限弹药！
 *难点4！！：boss的运动轨迹计算
 *规定触壁时改变方向，方向有16个0-15。分为四个部分，每个部分k斜率=0，0.5，1，2，-0.5。
 *然后每个部分的斜率知道 加减号不一样 斜对角k一样。注意：Jframe里的坐标系加减与数学
 *坐标系的不同
 *
 *难点4！！！！！：微信界面的聊天框：
 *思想：有很多个聊天气泡，聊天头像，聊天名字，所以创建了ArrayList 。
 *根据第几个 来初始化相对应的气泡，头像，名字。然后添加在panel中！！最难的时架构问题！！
 *
 * */
