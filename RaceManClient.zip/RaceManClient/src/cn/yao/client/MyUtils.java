package cn.yao.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.function.BiConsumer;

public class MyUtils {

	public static String reCrewData(String str,int length) {
		String rec = "";
		for(int i=0;i<length;i++) {
			rec+=" ";
		}
		if(str.length()>length)
			str = str.substring(0, length);
		str += rec.substring(0, length-str.length());
		return str;
	}
	
	public static String msTos(int ms) {
		return ms/1000+"."+ms/1000;
	}
	
}
