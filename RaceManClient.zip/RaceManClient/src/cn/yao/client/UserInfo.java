package cn.yao.client;

import java.net.Socket;

public class UserInfo {

	private String name;
	private String socketip;
	private String hostIp;
	private boolean isHost;
	private Socket socket;
	
	
	public UserInfo(String name, String socketip, String hostIp, boolean isHost,Socket socket) {
		this.name = name;
		this.socketip = socketip;
		this.hostIp = hostIp;
		this.isHost = isHost;
		this.socket = socket;
	}
	public UserInfo(String name,String hostIp, boolean isHost,Socket socket) {
		this.name = name;
		this.socketip = hostIp;
		this.hostIp = hostIp;
		this.isHost = isHost;
		this.socket = socket;

	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHostIp() {
		return hostIp;
	}
	public void setHostIp(String hostIp) {
		this.hostIp = hostIp;
	}
	public boolean isHost() {
		return isHost;
	}
	public void setHost(boolean isHost) {
		this.isHost = isHost;
	}
	public String getSocketip() {
		return socketip;
	}
	public void setSocketip(String socketip) {
		this.socketip = socketip;
	}
	public Socket getSocket() {
		return socket;
	}
	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	
	

}
