package cn.yao.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.InputMethodEvent;
import java.awt.event.InputMethodListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.net.ConnectException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Menu extends JFrame{
	private static final int WIDTH = 300;
	private static final int HEIGHT = 300;
	private JTextField ipAddress = new JTextField();
	private JButton link = new JButton("连接游戏");
	private JLabel ipLabel = new JLabel("请输入主机IP地址：");
	private JLabel myIpLabel = new JLabel();
	private JLabel linkInfo = new JLabel();
	private JButton newGame = new JButton("创建游戏");
	private JTextField nameText = new JTextField();
	private JLabel nameLabel = new JLabel("请输入游戏昵称:");
	private int msgGameType = 0;
	private int errorCode;
	private volatile String msgIpAddress = "";
	private volatile String myIp = "";
	private volatile String name = "";
	private volatile boolean isStart = false;
	public Menu() {

	}

	public void init() {
		this.setBounds(500, 200, WIDTH, HEIGHT);
		this.setBackground(Color.lightGray);
		this.setLayout(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setTitle("裸奔吧！兄弟！V2.0");
		try {
			myIp = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e1) {
			errorCode = 1;
			e1.printStackTrace();
		}
		msgGameType = 0;
		msgIpAddress = "";
		nameText.setBounds(120, 35, 150, 25);
		nameText.setFont(new Font("幼圆", Font.PLAIN, 15));
		nameLabel.setBounds(20, 40, 100, 15);
		linkInfo.setBounds(0, 240, 150, 15);
		linkInfo.setHorizontalAlignment(JLabel.RIGHT);
		myIpLabel.setBounds(20, 100, 150, 20);
		myIpLabel.setText("Ip:"+myIp);
		ipLabel.setBounds(20, 160, 200, 20);
		ipAddress.setBounds(20, 190, 128, 25);
		ipAddress.setFont(new Font("幼圆", Font.PLAIN, 15));
		newGame.setBounds(170, 100, 90, 25);
		newGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				msgGameType = 1;
				isStart = true;
				msgIpAddress = myIp;
				name = nameText.getText();
			}
		});
		link.setBounds(170, 190, 90, 25);
		link.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				msgIpAddress = ipAddress.getText();
				name = nameText.getText();
				msgGameType = 2;
				isStart = true;
			}
		});

		this.add(myIpLabel);
		this.add(ipLabel);
		this.add(linkInfo);
		this.add(link);
		this.add(newGame);
		this.add(ipAddress);	
		this.add(nameText);
		this.add(nameLabel);
		this.repaint();
		this.validate();
		this.doLayout();
	}

	public int getGameType() {
		return msgGameType;
	}
	public String getIpAddress() {
		return msgIpAddress;
	}
	public String getMyIp() {
		return myIp;
	}
	public boolean isStart() {
		return isStart;
	}
	public void setErrorMsg(int errorCode) {
		this.errorCode = errorCode;
		if(errorCode == 0) {
			linkInfo.setText("");
		}else
			linkInfo.setText("错误代码："+this.errorCode);
	}
	public String getName() {
		return name;
	}
	public static void main(String[] args) {
		Menu m = new Menu();
		m.init();
	}
}