package cn.yao.client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class MyServer extends JPanel{

	JTextArea receiver = new JTextArea();
	JTextArea sender = new JTextArea();
	JButton send = new JButton("发送");
	JScrollPane scrol = new JScrollPane(receiver);

	ServerSocket server;
	HashMap<String, UserInfo> sockets = new HashMap<>();

	ArrayList<String> records = new ArrayList<>();
	HashMap<String, ArrayList<UserInfo>> games = new  HashMap<>();
	//name+""+ip+"host"
	//	ArrayList<String> onlineUser = new ArrayList<>();





	socketsListener socketListenerAciton = new socketsListener();
	Thread socketListener = new Thread(socketListenerAciton);


	public MyServer() {
		try {
			String record = "";

			server = new ServerSocket(8088);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.setBounds(0, 0, 500, 500);
		this.setLayout(null);
		sender.setBounds(20, 200, 400, 200);
		sender.setLineWrap(true);

		receiver.setBounds(20, 20, 400, 150);
		receiver.setLineWrap(true);
		receiver.setWrapStyleWord(true);
		scrol.setBounds(20, 20, 400, 150);
		send.setBounds(200, 400, 100, 50);
		send.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
			}
		});
		this.add(send);
		this.add(scrol);
		this.add(sender);
		socketListener.start();
	}



	class socketsListener implements Runnable {

		public void run() {
			while(true) {
				try {
					Socket socket = server.accept();
					receiver.append(socket.getInetAddress()+"已连接！"+"\n");
					ReceiveListener receiveListenerAction = new ReceiveListener(socket);
					Thread receiveListener = new Thread(receiveListenerAction);
					receiveListener.start();

				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
	}

	class ReceiveListener implements Runnable{
		Socket socket;
		String name;
		String socketIp;
		String hostIp;
		boolean isHost; 
		String hostName;
		UserInfo user;
		ArrayList<UserInfo> newgame = new ArrayList<>();
		PrintWriter out ;
		BufferedReader in;
		PrintWriter outFile;
		BufferedReader inFile;
		public ReceiveListener(Socket socket) throws UnsupportedEncodingException, FileNotFoundException {
			this.socket = socket;
			socketIp = socket.getInetAddress()+"";
			socketIp = socketIp.substring(1);

		}
		public void run() {

			try {
				String rec = "";
				in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "utf-8"));
				inFile = new BufferedReader(new InputStreamReader(new FileInputStream("./result.txt"), "utf-8"));

				while(true) {
					rec = in.readLine();
					if(rec!=null) {
						receiver.append(rec+"\n");
						processData(rec);
					}
				}

			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				receiver.append(socket.getRemoteSocketAddress().toString()+"断开连接\n");
				e.printStackTrace();
			} finally {

			}
		}

		private void processData(String data) throws UnsupportedEncodingException, IOException {
			name = data.substring(1,11).trim();
			if("".equals(name) ) {
				name = "null";
			}
			String record = "";
			switch(data.charAt(0)) {
			case '1':
				isHost = (data.startsWith("1"));
				hostIp = data.substring(11);
				user = new UserInfo(name,hostIp,isHost,socket);
				sockets.put(socketIp+"host", user);
				newgame.add(user);
				games.put(hostIp+"host", newgame);
				out= new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "utf-8")),true);
				out.println("2"+MyUtils.reCrewData(name, 10)+socketIp);

				records.clear();
				record = inFile.readLine();
				//				inFile.mark((int) new File("./result.txt").length());
				while(record != null) {
					records.add(record);
					record = inFile.readLine();
				}
				System.out.println(records);
				for(int i=0;i<records.size();i++) {
					out.println(records.get(i));
				}
				System.out.println("连接主机地址:"+hostIp);
				System.out.println("名称:"+name);
				System.out.println("是否主机:"+isHost);
				System.out.println("自己地址"+socketIp);
				System.out.println("建立游戏了!");
				break;
			case '2':
				hostIp = data.substring(11);
				user = new UserInfo(name,socketIp,hostIp,false,socket);
				if(games.containsKey(hostIp+"host")) {//有创建新游戏

					sockets.put(socketIp, user);
					games.get(hostIp+"host").add(user);//加入游戏
					sender.append(name+"人数："+games.get(hostIp+"host").size());
					//有人进来 需要给所有当前游戏的客户端发送新加入伙伴信息
					for(int i=0;i<games.get(hostIp+"host").size();i++) {
						UserInfo userTemp = games.get(hostIp+"host").get(i);
						for(int j=0;j<games.get(hostIp+"host").size();j++) {
							out= new PrintWriter(new BufferedWriter(new OutputStreamWriter(games.get(hostIp+"host").get(j).getSocket().getOutputStream(), "utf-8")),true);
							out.println("2"+MyUtils.reCrewData(userTemp.getName(), 10)+userTemp.getSocketip());
						}
					}

					System.out.println(records);
					//gamer加入游戏就会发过去游戏记录！4开头
					for(int i=0;i<records.size();i++) {
						out.println(records.get(i));
					}
					System.out.println("#连接主机地址:"+hostIp);
					System.out.println("#名称:"+name);
					System.out.println("#是否主机:"+isHost);
					System.out.println("#自己地址"+socketIp);
					System.out.println("加入游戏了!");
				}

				break;
			case '3':
				//3+name+" "+ip+$+x+$+hostip
				String datas[];
				datas = data.split("[$]");
				socketIp = datas[0].substring(11);
				name = datas[0].substring(1, 11);
				hostIp = datas[2];
				if(games.containsKey(hostIp+"host")) {
					//确认传输数据方是这局游戏的
					if(Integer.parseInt(datas[1])<435) {
						for(int j=0;j<games.get(hostIp+"host").size();j++) {
							out= new PrintWriter(new BufferedWriter(new OutputStreamWriter(games.get(hostIp+"host").get(j).getSocket().getOutputStream(), "utf-8")),true);
							out.println(data);
						}
					}else {//到达终点 产生
						for(int j=0;j<games.get(hostIp+"host").size();j++) {
							out= new PrintWriter(new BufferedWriter(new OutputStreamWriter(games.get(hostIp+"host").get(j).getSocket().getOutputStream(), "utf-8")),true);
							out.println("5"+datas[0].substring(1)+"$"+datas[3]);

						}
					}

				}
				break;
			case '4'://到达终点 往文件写记录
				System.out.println("ff"+data);
				Date date = new Date();
				DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				outFile	= new PrintWriter(new OutputStreamWriter(new FileOutputStream("./result.txt",false), "utf-8"),true);
				outFile.write("");
				outFile.close();
				outFile	= new PrintWriter(new OutputStreamWriter(new FileOutputStream("./result.txt",true), "utf-8"),true);
				int resultNew = Integer.parseInt(data.split("[$]")[3]);
				for(int i=0;i<5;i++) {
					if(resultNew<Integer.parseInt(records.get(i).split("[$]")[3])) {
						records.set(i, data+"$"+df.format(date));
						break;
					}
				}
				for(int i=0;i<5;i++) {
					outFile.println(records.get(i));
				}

				break;
			case '6'://开始
				hostIp = data.substring(1);
				for(int j=0;j<games.get(hostIp+"host").size();j++) {

					out= new PrintWriter(new BufferedWriter(new OutputStreamWriter(games.get(hostIp+"host").get(j).getSocket().getOutputStream(), "utf-8")),true);
					out.println("6");

				}
				break;
			}
		}

	}
	public static void main(String[] args) {
		MyServer server = new MyServer();
		JFrame frame = new JFrame("裸奔吧！兄弟！服务器");
		frame.setBounds(900, 300, 500,500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.add(server);
		frame.setVisible(true);
	}
}