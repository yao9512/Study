package cn.yao.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class GameClient extends JFrame{


	public final static int endLineX = 450;
	public final static int WIDTH = 700;

	private Color[] colors = {Color.red,Color.DARK_GRAY,Color.yellow,Color.blue,Color.gray,Color.green,Color.pink,Color.orange};
	private JLabel[] heros = new JLabel[8];
	private JTextArea text = new JTextArea();
	private JTextArea wordRecord = new JTextArea();
	private JButton start = new JButton("开始游戏");
	private JLabel[] heroNames = new JLabel[6];
	private JLabel endLine = new JLabel();
	private JLabel info = new JLabel();
	private JLabel timeCount = new JLabel();
	private JScrollPane scrol = new JScrollPane(wordRecord);

	private int you;
	private boolean isHost;
	private volatile int x;
	private volatile int y;
	private volatile boolean startFlag = false;
	private volatile boolean countEnd = false;
	public GameClient(boolean isHost) {

		this.isHost = isHost;
		y = 220;
		x = 80;

	}


	public void init() {
		this.setBounds(500,200, WIDTH, 350);
		this.setLayout(null);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		scrol.setBounds(455, 0, 240, 150);
		wordRecord.setBounds(455, 0, 240, 150);
		wordRecord.setLineWrap(true);
		wordRecord.setEditable(false);
		wordRecord.setBackground(Color.LIGHT_GRAY);
		wordRecord.setFocusable(false);
		text.setBounds(455, 151, 240, 160);
		text.setLineWrap(true);
		text.setEditable(false);
		text.setBackground(Color.LIGHT_GRAY);
		text.setFocusable(false);

		timeCount.setBounds(220, 10, 100, 20);
		timeCount.setFocusable(false);
		endLine.setBounds(endLineX,0,3,280);
		endLine.setOpaque(true);
		endLine.setBackground(Color.DARK_GRAY);
		info.setBounds(0, 0, 200, 20);
		for(int i=0;i<6;i++) {
			heros[i] = new JLabel();
			heros[i].setBounds(x, y-(i*30), 15, 15);
			heros[i].setOpaque(true);
			heros[i].setBackground(colors[i]);
			heros[i].setVisible(false);
			heroNames[i] = new JLabel();
			heroNames[i].setBounds(5, y-(i*30), 60, 15);
			heroNames[i].setVisible(true);
			this.add(heroNames[i]);
			this.add(heros[i]);
		}
		start.setBounds(300, 10, 80, 30);
		start.setMargin(new Insets(0, 0, 0, 0));
		start.setFocusable(false);
		start.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				startFlag = true;
			}
		});
		if(isHost) {
			start.setVisible(true);
		}else {
			start.setVisible(false);
		}
		this.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				if(startFlag && countEnd) {
					switch(e.getKeyCode()) {
					case KeyEvent.VK_RIGHT:
						x += 5;
						if(x>endLineX-5) {
							x = endLineX-5;
						}
						break;
					}
				}

			}
		}); 
		this.add(scrol);
		this.add(text);
		this.add(start);
		this.add(info);
		this.add(endLine);
		this.add(timeCount);
		this.repaint();
		this.validate();
		this.doLayout();
	}


	public void run(int index) {
		heros[index].setLocation(heros[index].getX()+1, heros[index].getY());
	}
	public void addHero(int index,String name) {
		heros[index].setVisible(true);
		heroNames[index].setText(name);
	}
	public int getX() {
		return x;
	}

	public void setX(int index,int x) {
		heros[index].setLocation(x, y-(index*30));
	}

	public int getY() {
		return y;
	}

	public void setInfoLine(String str) {
		info.setText(str);
	}
	public void setY(int y) {
		this.y = y;
	}

	public void setYou(int num) {
		you = num;
	}
	public static void main(String[] args) {
		GameClient a = new GameClient(true);
		a.init();
	}
	public boolean isStart() {
		return startFlag;
	}
	public void setWorldRecord(String str) {
		String[] datas2 = str.split("[$]");
		String str1 = "";
		
		str1 = datas2[0].substring(1, 11).trim()+datas2[0].substring(11)+"\n"+
				"成绩："+new DecimalFormat("#.00").format(((Integer.parseInt(datas2[3])*0.01)))+"s ："+
				datas2[4];
		wordRecord.append(str1+"\n");
	}
	public void appendResut(String str) {
		text.append(str+"\n");
	}
	public void stop() {
		this.startFlag = false;
	}
	public void start() { 
		countEnd = true;
		startFlag = true;
	}
	public void setTime(long str) {//1 == 0.01s
		timeCount.setText(new DecimalFormat("#.00").format((str*0.01))+"s");
	}
	public void setTitle(String str,int isHost) {
		
		this.setTitle(str+(isHost==1?"主机":"客户机"));
	}

}
