package cn.yao.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.Inet4Address;
import java.net.Socket;
import java.net.UnknownHostException;

public class ComToHost {
	private static final String HOST = "172.201.6.85";
	private Socket socket;
	private int errorCode;
	private PrintWriter out;
	private BufferedReader in;
	private StringBuffer data = new StringBuffer();
	
	public void init() {
		try {
			socket = new Socket(HOST, 8088);
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
			errorCode = 1;
		} catch (IOException e1) {
			e1.printStackTrace();
			errorCode = 2;
		}
		
	}

	public void outputInit() {
		try {
			out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "utf-8")),true);
		} catch (UnsupportedEncodingException e) {
			errorCode = 3;
			e.printStackTrace();
		} catch (IOException e) {
			errorCode = 2;
			e.printStackTrace();
		}
		
	}

	public void intputInit() {
		try {
			in	= new BufferedReader(new InputStreamReader(socket.getInputStream(), "utf-8"));
			
		} catch (UnsupportedEncodingException e) {
			errorCode = 3;
			e.printStackTrace();
		} catch (IOException e) {
			errorCode = 2;
			e.printStackTrace();
		}
	}
	public void writeData(StringBuffer data) {
		out.println(data);
	}
	public String readDate() {
		String str = "";
		try {
			str = in.readLine();
		} catch (IOException e) {
			errorCode = 2;
			e.printStackTrace();
		}
		return str;
	}
	public void newGameInit(int gameType,String ip,String name) {
		data.delete(0	, data.length()+1);
		data.append(gameType);
		data.append(name);
		data.append(ip);
		out.println(data); 
	}
	
	public int getErrorCode() {
		return errorCode;
	}
}
