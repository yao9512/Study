package cn.yao.client;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;

public class RunClient {

	private ComToHost com;
	private Menu menu;
	private GameClient game;
	private volatile String name;

	private volatile long timeCount = 0;
	private String hostIp = "";
	private volatile int errorCode;
	private volatile int mainState;
	private volatile int startFlag = 0;

	private ArrayList<String> gameResult = new ArrayList<>();
	private volatile HashMap<String, Integer> herosJoin = new HashMap<>();
	//保存的是  name+空格+ip
	private String localIp;
	private String desIp;
	private ThreadMain thredMainAction = new ThreadMain();
	private Thread threadMain = new Thread(thredMainAction);

	private volatile StringBuffer data = new StringBuffer();

	private ThreadComWrite threadComWriteAction = new ThreadComWrite();
	private Thread threadComWrite = new Thread(threadComWriteAction);

	private ThreadComRead threadComReadAction = new ThreadComRead();
	private Thread threadComRead = new Thread(threadComReadAction);

	private ThreadGetErrors threadGetErrorsAction= new ThreadGetErrors();
	private Thread threadGetErrors = new Thread(threadGetErrorsAction);
	public void start() {
		mainState = 0; 
		threadMain.start();
		threadComRead.start();
		threadComWrite.start();
		threadGetErrors.start();
	}

	public class ThreadMain implements Runnable{
		public void run() {
			menu = new Menu();
			menu.init();
			nextState();//1
			com = new ComToHost();
			nextState();//2
			com.init();
			nextState();//3
			com.outputInit();
			com.intputInit();
			nextState();//4
			while(!menu.isStart()) {

			}
			name = menu.getName();
			switch(menu.getGameType()) {
			case 1:
				localIp = menu.getMyIp();
				com.newGameInit(menu.getGameType(), localIp, MyUtils.reCrewData(name, 10));
				break;
			case 2:
				desIp = menu.getIpAddress();
				com.newGameInit(menu.getGameType(), desIp, MyUtils.reCrewData(name, 10));
				break;
			}
			game= new GameClient(menu.getGameType()==1);
			game.init();
			game.setTitle(menu.getName(),menu.getGameType());
			menu.setVisible(false);
			nextState();//5
		}

	}

	public class ThreadComWrite implements Runnable{

		public void run() {
			while(mainState<5) {
				//等待程序画面流等初始化完毕
			}
			if(menu.getGameType() == 1) {
				while(!game.isStart()) {
					//等待主机按开始游戏
				}
				data.delete(0, data.length()+1);
				com.writeData(data.append("6"+menu.getIpAddress()));
			}
			while(startFlag<1) {
				//客机的等待开始游戏
			}
			for(int i=5;i>0;i--) {//倒计时
				game.setInfoLine(i+"");
				try {
					Thread.sleep(1000); 
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			data.delete(0, data.length()+1);
			game.setInfoLine("开始裸奔吧！");
			game.start();
			nextState();//6
			while(mainState == 6) {
				if(mainState>=6) {
					timeCount++;
					game.setTime(timeCount);
					data.delete(0, data.length()+1);
					data.append("3"+MyUtils.reCrewData(menu.getName(), 10)+menu.getMyIp()+"$"+game.getX()+"$"+hostIp);
					data.append("$"+timeCount);
					
					com.writeData(data);

				}
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					errorCode = 5;
					e.printStackTrace();
				}


			}
			
		}

	}
	public class ThreadComRead implements Runnable{

		String str = "";
		public void run() {
			while(true) {
				if(mainState>=5) {
					str = com.readDate();
					switch(str.charAt(0)) {
					case '1'://游戏创建成功
						//						System.out.println(str);
						//						game.addHero(0);
						//						game.setYou(0);
						break;
					case '2'://游戏加入成功!
						hostIp = menu.getIpAddress();
						name = menu.getName();
						if(herosJoin.size()<6) {
							//判断游戏中是否有我

							if(!herosJoin.containsKey(str.substring(1))) {
								if(str.substring(1).equals(MyUtils.reCrewData(name, 10)+localIp)){
									game.setYou(herosJoin.size());
								}
								herosJoin.put(str.substring(1), herosJoin.size());		
								game.addHero(herosJoin.get(str.substring(1)),str.substring(1, 11).trim());
							}
							//							if(herosJoin.containsKey( MyUtils.reCrewData(name, 10)+localIp)) {
							//								//游戏中有我 传过来的信息不是我
							//								if(!herosJoin.containsKey(str.substring(1))) {
							//									System.out.println("f2");
							//									herosJoin.put(str.substring(1), herosJoin.size());		
							//									game.addHero(herosJoin.get(str.substring(1)),str.substring(1, 11).trim());
							//								}
							//							}else {				
							//								System.out.println("f1");
							//								game.setYou(herosJoin.size());
							//								herosJoin.put(str.substring(1), herosJoin.size());		
							//								game.addHero(herosJoin.get(str.substring(1)),str.substring(1, 11).trim());
							//							}

						}
						break;
					case '3'://正式传输游戏数据
						String datas[];
						datas = str.split("[$]");
						localIp = menu.getMyIp();
						name = menu.getName();
						game.setX(herosJoin.get(datas[0].substring(1)),Integer.parseInt(datas[1]));
						break;
					case '4'://获得记录
						game.setWorldRecord(str);
						
						break;
					case '5'://到到终点获得成绩
						String datas1[];
						datas1 = str.split("[$]");
						name = datas1[0].substring(1,11).trim();
						String recIp = datas1[0].substring(11);
						if(!gameResult.contains(datas1[0])) {
							gameResult.add(datas1[0]);
							game.appendResut(name+"("+recIp+")"+new DecimalFormat("#.00").format((Integer.parseInt(datas1[1])*0.01))+"s");
							if(datas1[0].substring(1).equals(MyUtils.reCrewData(menu.getName(), 10)+menu.getMyIp())) {
								data.delete(0, data.length()+1);
								data.append("4"+MyUtils.reCrewData(menu.getName(), 10)+menu.getMyIp()+"$"+game.getX()+"$"+hostIp);
								data.append("$"+timeCount);
								com.writeData(data);
							}
						}
						
//						nextState();//7

						break;

					case '6'://开始
						startFlag = 1;
						break;
					}
				}
			}
		}

	}
	public class ThreadGetErrors implements Runnable{

		public void run() {
			while(true) {
				if(mainState >= 2) {
					errorCode = com.getErrorCode();
					menu.setErrorMsg(errorCode);
				}
			}
		}

	}

	public void nextState() {
		this.mainState++;
	}
	public static void main(String[] args) {

		RunClient run = new RunClient();
		run.start();
	}


}
