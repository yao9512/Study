package cn.yao.client;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class Test {

	public static void main(String[] args) {
		String name = "1a$aa$  $  $  $as$ss";
		String[] n = name.split("[$]");
		System.out.println(Arrays.toString(n));
		Date d = new Date();
		DateFormat dd = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
		System.err.println(dd.format(d));
	}

}
