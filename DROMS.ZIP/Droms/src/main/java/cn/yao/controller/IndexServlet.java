package cn.yao.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.context.Context;

import cn.yao.entity.Person;
import cn.yao.utils.ThUtils;

/**
 * Servlet implementation class IndexServlet
 */
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Context context = new Context();
		HttpSession session = request.getSession();
		Person p = (Person) session.getAttribute("user");
		String type = (String) session.getAttribute("usertype");
		if(p==null||type==null) {
			response.sendRedirect(request.getContextPath()+"/LoginServlet");
			return;
		}
		context.setVariable("usertype", type.equals("admin")?"系统管理员":(type.equals("manager")?"宿舍管理员":"学生"));
		context.setVariable("name", p.getname());
		ThUtils.write("index", context, response);
	}


}
