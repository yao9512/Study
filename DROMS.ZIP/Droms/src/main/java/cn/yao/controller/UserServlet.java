package cn.yao.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.context.Context;

import cn.yao.dao.ManagerDao;
import cn.yao.entity.Manager;
import cn.yao.entity.Person;
import cn.yao.entity.ThPage;
import cn.yao.utils.ThUtils;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public static final int PAGE_LIMIT = 6;//一页显示条数
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//登陆状态检测
		Context context = new Context();
		HttpSession session = request.getSession();
		Person p = (Person) session.getAttribute("user");
		String type = (String) session.getAttribute("usertype");
		if(p==null||type==null) {
			response.sendRedirect(request.getContextPath()+"/LoginServlet");
			return;
		}
		//处理业务
		int page = 1;//当前页面
		String data_page = request.getParameter("page");//请求的页码
		String searchType = request.getParameter("searchType");//请求搜索
		String keyWord = request.getParameter("keyWord");
		int pageSum = 0;//总共的页数
		int count = 0;//总共的数据
		ArrayList<ThPage> pages = new ArrayList<>();//Page类 用于Thymeleaf页码显示
		List<Manager> list = null;//查找到的数据
		ManagerDao dao_m = new ManagerDao();
		
		if(data_page == null) {
			page = 1;
		}else {
			page = Integer.parseInt(data_page);
		}
		
		if("".equals(keyWord)||keyWord==null) {
			
			count = dao_m.getManagerCount();//一共多少条数据
			list = dao_m.findManagers(page,PAGE_LIMIT);
		}else {
			if("name".equals(searchType)) {
				count = dao_m.getManagerCountByName(keyWord);
				list = dao_m.findManagersByName(keyWord,page,PAGE_LIMIT);
			}else if("type".equals(searchType)){
				count = dao_m.getManagerCountByType(keyWord);
				list = dao_m.findManagersByType(keyWord,page,PAGE_LIMIT);
			}
			context.setVariable("keyWord", keyWord);
			context.setVariable("searchType",searchType);
		}
		
		
		pageSum = (int) Math.ceil(count/(PAGE_LIMIT/1.0));//计算多少页
		for(int i=0;i<pageSum;i++) {
			ThPage thPage = new ThPage(i+1, page==(i+1)?"active":"");
			pages.add(thPage);
		}
		if(page==1) {
			context.setVariable("nextPage", "");
			context.setVariable("lastPage", "disabled");

		}else if(page==pageSum) {
			context.setVariable("nextPage", "disabled");
			context.setVariable("lastPage", "");
		}else {
			context.setVariable("nextPage", "");
			context.setVariable("lastPage", "");
		}
		context.setVariable("userlist", list);
		context.setVariable("pages", pages);
		context.setVariable("page", page);
		context.setVariable("Maxpage", pageSum);
		
		ThUtils.write("user", context, response);
		
		
	}

	

}
