package cn.yao.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.context.Context;

import cn.yao.dao.BuildingDao;
import cn.yao.dao.ManagerDao;
import cn.yao.dao.StudentDao;
import cn.yao.entity.Building;
import cn.yao.entity.Manager;
import cn.yao.entity.Person;
import cn.yao.entity.Student;

/**
 * Servlet implementation class EditServlet
 */
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//登陆状态检测
		HttpSession session = request.getSession();
		Person p = (Person) session.getAttribute("user");
		String type = (String) session.getAttribute("usertype");
		if(p==null||type==null) {
			response.sendRedirect(request.getContextPath()+"/LoginServlet");
			return;
		}
		request.setCharacterEncoding("utf-8");
		String uri = request.getRequestURI();
		if("/Droms/house-manager.edit".equals(uri)) {
			
			int bid = 0;
			Enumeration<String> e = request.getParameterNames();
			while(e.hasMoreElements()) {
				bid = Integer.parseInt(e.nextElement());
			}
			String[] midStr = request.getParameterValues(bid+"");
			ManagerDao dao_m = new ManagerDao();
			System.out.println(bid);
			System.out.println(Arrays.toString(midStr));
			dao_m.buildingInitManager(bid);
			for(int i=0;i<midStr.length;i++) {
				dao_m.addManagerToBuilding(Integer.parseInt(midStr[i]), bid);
			}
			response.sendRedirect(request.getContextPath()+"/house.html");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//登陆状态检测
		HttpSession session = request.getSession();
		Person p = (Person) session.getAttribute("user");
		String type1 = (String) session.getAttribute("usertype");
		if(p==null||type1==null) {
			response.sendRedirect(request.getContextPath()+"/LoginServlet");
			return;
		}
		request.setCharacterEncoding("utf-8");
		String uri = request.getRequestURI();
		if("/Droms/admin.edit".equals(uri)) {
			String id = request.getParameter("id");
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String name = request.getParameter("name");
			String sex = request.getParameter("sex");
			String type = request.getParameter("type");
			String phone = request.getParameter("phone");
			String[] bid = request.getParameter("bid").split("[!]");
			Manager m = new Manager(Integer.parseInt(id), name, sex, phone,Integer.parseInt(bid[0]), bid[1], type, username, password);
			ManagerDao dao_m = new ManagerDao();
			dao_m.updateById(Integer.parseInt(id), m);
			response.sendRedirect(request.getContextPath()+"/user.html");
		}
		if("/Droms/student.edit".equals(uri)) {
			String id = request.getParameter("id");
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String name = request.getParameter("name");
			String sex = request.getParameter("sex");
			String dor = request.getParameter("dor");
			String phone = request.getParameter("phone");
			String[] bid = request.getParameter("bid").split("[!]");
			Student s = new Student(Integer.parseInt(id), name, sex, phone, Integer.parseInt(bid[0]), bid[1], dor, username, password);
			StudentDao dao_s = new StudentDao();
			dao_s.updateById(Integer.parseInt(id), s);
			response.sendRedirect(request.getContextPath()+"/student.html");
		}
		if("/Droms/house.edit".equals(uri)) {
			String id = request.getParameter("id");
			String bname = request.getParameter("bname");
			String bintro = request.getParameter("bintro");
			Building b = new Building(Integer.parseInt(id), bname, bintro);
			BuildingDao dao_b = new BuildingDao();
			dao_b.updateById(Integer.parseInt(id), b);
			response.sendRedirect(request.getContextPath()+"/house.html");
		}
		
	}

}
	