package cn.yao.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.context.Context;

import cn.yao.dao.BuildingDao;
import cn.yao.dao.ManagerDao;
import cn.yao.dao.StudentDao;
import cn.yao.dao.WorkDao;
import cn.yao.entity.Person;

/**
 * Servlet implementation class DeleteServlet
 */
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//登陆状态检测
		HttpSession session = request.getSession();
		Person p = (Person) session.getAttribute("user");
		String type = (String) session.getAttribute("usertype");
		if(p==null||type==null) {
			response.sendRedirect(request.getContextPath()+"/LoginServlet");
			return;
		}
		String uri = request.getRequestURI();
		if("/Droms/admin.delete".equals(uri)) {
			String id = request.getParameter("id");
			ManagerDao dao_m = new ManagerDao();
			dao_m.deleteById(Integer.parseInt(id));
			response.sendRedirect(request.getContextPath()+"/user.html");
		}
		if("/Droms/student.delete".equals(uri)) {
			String id = request.getParameter("id");
			StudentDao dao_s = new StudentDao();
			dao_s.deleteById(Integer.parseInt(id));
			response.sendRedirect(request.getContextPath()+"/student.html");
		}
		if("/Droms/house.delete".equals(uri)) {
			String id = request.getParameter("id");
			BuildingDao dao_b = new BuildingDao();
			boolean result = dao_b.deleteById(Integer.parseInt(id));
			
			response.sendRedirect(request.getContextPath()+"/house.html?result_D="+result);
		}
		if("/Droms/work.delete".equals(uri)) {
			String id = request.getParameter("id");
			WorkDao dao_w = new WorkDao();
			dao_w.deleteById(Integer.parseInt(id));
			
			response.sendRedirect(request.getContextPath()+"/work.html");
		}
	}


}
