package cn.yao.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.context.Context;

import cn.yao.entity.Manager;
import cn.yao.entity.Person;
import cn.yao.entity.Student;
import cn.yao.utils.PersonUtils;
import cn.yao.utils.ThUtils;



public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String usertype = req.getParameter("usertype");
		String remember = req.getParameter("remember");
		Person p = PersonUtils.getPerson(username, password, usertype);
		if(p!=null) {
			if("on".equals(remember)) {
				//记住我 添加cookie
				ArrayList<Cookie> cookies = new ArrayList<>();
				cookies.add(new Cookie("username", username));
				cookies.add(new Cookie("password", password));
				cookies.add(new Cookie("usertype", usertype));
				cookies.add(new Cookie("remember", remember));
				for(Cookie c:cookies) {
					c.setMaxAge(60*60*24*7);
					resp.addCookie(c);
				}
			}else if(null==remember){
				ArrayList<Cookie> cookies = new ArrayList<>();
				cookies.add(new Cookie("username", null));
				cookies.add(new Cookie("password", null));
				cookies.add(new Cookie("usertype", null));
				cookies.add(new Cookie("remember", null));
				for(Cookie c:cookies) {
					c.setMaxAge(0);
					resp.addCookie(c);
				}
			}
			//登陆成功处理
			//1.session
			HttpSession session = req.getSession();
			if (p instanceof Manager) {
				Manager manager = (Manager) p;
				session.setAttribute("user", manager);
				session.setAttribute("usertype", manager.getType());
			}
			if (p instanceof Student) {
				Student student = (Student) p;
				session.setAttribute("user", student);
				session.setAttribute("usertype", "student");
			}
			//2.重定向
			resp.sendRedirect(req.getContextPath()+"/TemplateServlet");
		}else {
			resp.setContentType("text/html;charset=utf-8");
			PrintWriter pw = resp.getWriter();
			pw.print("登录失败");
			pw.close();
		}

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Context context = new Context();

		//session处理
		
		
		//cookie获取值
		Cookie[] cookies = request.getCookies();
		if(cookies!=null) {
			for(Cookie c:cookies) {
				if("username".equals(c.getName())) {
					context.setVariable("username", c.getValue());
				}
				if("password".equals(c.getName())) {
					context.setVariable("password", c.getValue());
				}
				if("usertype".equals(c.getName())) {
					context.setVariable("usertype", c.getValue());
				}
				if("remember".equals(c.getName())) {
					context.setVariable("remember", c.getValue());
				}
				
			}
		}
		
		
		//常规登陆
		ThUtils.write("login", context, response);
	}

	


	
}
