package cn.yao.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.context.Context;

import cn.yao.entity.Person;
import cn.yao.utils.PersonUtils;
import cn.yao.utils.ThUtils;

/**
 * Servlet implementation class TemplateServlet
 */
public class TemplateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//通过session判断登陆状态
		HttpSession session = request.getSession();
		Person p = (Person) session.getAttribute("user");
		String usertype = (String) session.getAttribute("usertype");
		Context context = new Context();
		//session 没有数据 直接去登陆页面
		if(PersonUtils.isInDatabase(p, usertype)) {
			context.setVariable("name", p.getname());
		}else {
			response.sendRedirect(request.getContextPath()+"/LoginServlet");
		}
		
		ThUtils.write("template", context, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
