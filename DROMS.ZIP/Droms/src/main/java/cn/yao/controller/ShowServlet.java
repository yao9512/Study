package cn.yao.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.context.Context;

import cn.yao.dao.BuildingDao;
import cn.yao.dao.ManagerDao;
import cn.yao.dao.StudentDao;
import cn.yao.entity.Building;
import cn.yao.entity.Manager;
import cn.yao.entity.Person;
import cn.yao.entity.Student;
import cn.yao.utils.ThUtils;

/**
 * Servlet implementation class Show
 */
public class ShowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//登陆状态检测
		HttpSession session = request.getSession();
		Person p = (Person) session.getAttribute("user");
		String type = (String) session.getAttribute("usertype");
		if(p==null||type==null) {
			response.sendRedirect(request.getContextPath()+"/LoginServlet");
			return;
		}
		String uri = request.getRequestURI();
		BuildingDao dao_b = new BuildingDao();
		ManagerDao dao_m = new ManagerDao();
		StudentDao dao_s = new StudentDao();
		List<Building> list_building = dao_b.findAll();
		if("/Droms/add-admin.show".equals(uri)) {
			Context context = new Context();
			context.setVariable("BuildingList", list_building);
			ThUtils.write("add-admin", context, response);
		}
		if("/Droms/edit-admin.show".equals(uri)) {
			Context context = new Context();
			if(null!=request.getParameter("id")) {
				int id = Integer.parseInt(request.getParameter("id"));
				Manager m = dao_m.getManagerById(id);
				context.setVariable("man", m);
			}
			
			
			context.setVariable("BuildingList", list_building);
			ThUtils.write("edit-admin", context, response);
		}
		if("/Droms/add-student.show".equals(uri)) {
			Context context = new Context();
			context.setVariable("BuildingList", list_building);
			ThUtils.write("add-student", context, response);
		}
		if("/Droms/edit-student.show".equals(uri)) {
			Context context = new Context();
			context.setVariable("BuildingList", list_building);
			if(null!=request.getParameter("id")) {
				int id = Integer.parseInt(request.getParameter("id"));
				Student s = dao_s.getStudentById(id);
				context.setVariable("stu", s);
			}
			ThUtils.write("edit-student", context, response);
		}
		if("/Droms/add-house.show".equals(uri)) {
			ThUtils.write("add-house", new Context(), response);
		}
		if("/Droms/edit-house.show".equals(uri)) {
			Context context = new Context();
			if(null!=request.getParameter("id")) {
				int id = Integer.parseInt(request.getParameter("id"));
				Building b = dao_b.getBuildingById(id);
				context.setVariable("bud", b);
			}
			ThUtils.write("edit-house", context, response);
		}
	}


}
