package cn.yao.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.thymeleaf.context.Context;

import cn.yao.dao.BuildingDao;
import cn.yao.dao.StudentDao;
import cn.yao.dao.WorkDao;
import cn.yao.entity.Absence;
import cn.yao.entity.Building;
import cn.yao.entity.Person;
import cn.yao.entity.Student;
import cn.yao.entity.ThPage;
import cn.yao.utils.ThUtils;

/**
 * Servlet implementation class WorkServlet
 */
public class WorkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final int PAGE_LIMIT = 6;//一页显示条数

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//登陆状态检测
		Context context = new Context();
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Person p = (Person) session.getAttribute("user");
		String type = (String) session.getAttribute("usertype");
		if(p==null||type==null) {
			response.sendRedirect(request.getContextPath()+"/LoginServlet");
			return;
		}
		//处理业务
		int page = 1;//当前页面
		String data_page = request.getParameter("page");//请求的页码
		String keyWord = request.getParameter("keyWord");
		String bidStr = request.getParameter("bid");
		String date_start = request.getParameter("date_start");
		String date_end = request.getParameter("date_end");
		String searchType = request.getParameter("searchType");
		int pageSum = 0;//总共的页数
		int count = 0;//总共的数据
		ArrayList<ThPage> pages = new ArrayList<>();//Page类 用于Thymeleaf页码显示
		List<Absence> list = null;//查找到的数据
		WorkDao dao_w = new WorkDao();
		
		if(data_page == null) {
			page = 1;
		}else {
			page = Integer.parseInt(data_page);
		}
		
		if((keyWord==null&&bidStr==null&&(date_start==null||date_end==null))||
			(("".equals(date_end)||"".equals(date_start))&&"".equals(keyWord)&&"all".equals(bidStr.split("[!]")[0]))) {
			//正常显示全部
			count = dao_w.getWorkCount();//一共多少条数据
			list = dao_w.findAll(page,PAGE_LIMIT);
		}else {
			String bid = bidStr.split("[!]")[0];
			count = dao_w.findWorkCount(date_start, date_end, bid, searchType,keyWord);
			list = dao_w.findWorks(date_start, date_end, bid, searchType,keyWord,page,PAGE_LIMIT);

		}
		BuildingDao dao_b = new BuildingDao();
		List<Building> list_building = dao_b.findAll();
		pageSum = (int) Math.ceil(count/(PAGE_LIMIT/1.0));//计算多少页
		for(int i=0;i<pageSum;i++) {
			ThPage thPage = new ThPage(i+1, page==(i+1)?"active":"");
			pages.add(thPage);
		}
		if(page==1) {
			context.setVariable("nextPage", "");
			context.setVariable("lastPage", "disabled");

		}else if(page==pageSum) {
			context.setVariable("nextPage", "disabled");
			context.setVariable("lastPage", "");
		}else {
			context.setVariable("nextPage", "");
			context.setVariable("lastPage", "");
		}
		context.setVariable("list", list);//所有缺勤人
		context.setVariable("pages", pages);//page类
		context.setVariable("page", page);//现在第几页
		context.setVariable("Maxpage", pageSum);//最大页数	
		context.setVariable("BuildingList", list_building);
		
		ThUtils.write("work", context, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
