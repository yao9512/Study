package cn.yao.utils;

import cn.yao.dao.ManagerDao;
import cn.yao.dao.StudentDao;
import cn.yao.entity.Person;

public class PersonUtils {
	public static Person getPerson(String username,String password,String type) {
		Person p = null;
		if("student".equals(type)) {
			StudentDao dao_s = new StudentDao();
			p = dao_s.loginStudent(username, password);
		}else {
			ManagerDao dao_m = new ManagerDao();
			p= dao_m.loginManager(username, password, type);
		}
		return p;
	}
	public static boolean isInDatabase(Person p,String usertype) {
		if(p!=null) {
			Person p_query = PersonUtils.getPerson(p.getusername(), p.getpassword(), usertype);
			if(p_query==null) {
				return false;
			}else {
				return true;
			}
		}else {
			return false;
		}
	}
}
