package cn.yao.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.yao.controller.UserServlet;
import cn.yao.entity.Manager;
import cn.yao.entity.Student;
import cn.yao.utils.DBUtils;

public class ManagerDao {

	public Manager loginManager(String username,String password,String mtype) {
		Manager m = null;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from managers m,buildings b where m.bid=b.bid and musername=? and mpassword=? and mtype=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.setString(3, mtype);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				m = new Manager(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(9), rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return m;
	}
	public List<Manager> findAll(){
		ArrayList<Manager> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from managers m,buildings b where m.bid=b.bid";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				list.add(new Manager(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(9), rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public List<Manager> findManagers(int page,int pageSum){
		ArrayList<Manager> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from managers m,buildings b where m.bid=b.bid limit ?,?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, (page-1)*UserServlet.PAGE_LIMIT);
			ps.setInt(2, pageSum);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Manager(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(9), rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public int getManagerCount() {
		int count = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select count(*) from managers";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public int getManagerCountByType(String keyWord) {
		int count = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select count(*) from managers where mtype=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, keyWord);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public int getManagerCountByName(String keyWord) {
		int count = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select count(*) from managers where mname like?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "%"+keyWord+"%");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public List<Manager> findManagersByName(String keyWord,int page,int pageMax) {
		ArrayList<Manager> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from managers m,buildings b where m.bid=b.bid and mname like ? limit ?,?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "%"+keyWord+"%");
			ps.setInt(2, (page-1)*UserServlet.PAGE_LIMIT);
			ps.setInt(3, pageMax);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Manager(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(9), rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public List<Manager> findManagersByType(String keyWord,int page,int pageMax) {
		ArrayList<Manager> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from managers m,buildings b where m.bid=b.bid and mtype=? limit ?,?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, keyWord);
			ps.setInt(2, (page-1)*UserServlet.PAGE_LIMIT);
			ps.setInt(3, pageMax);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Manager(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(9), rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public boolean addManager(Manager m) {
		int result = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "insert into managers values(0,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, m.getname());
			ps.setString(2, m.getsex());
			ps.setString(3, m.getphone());
			ps.setInt(4, m.getBid());
			ps.setString(5, m.getType());
			ps.setString(6, m.getusername());
			ps.setString(7, m.getpassword());
			
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result==1?true:false;
	}
	public boolean deleteById(int id) {
		int result = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "delete from managers where mid =?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result==1?true:false;
	}
	public boolean updateById(int id,Manager m) {
		int result = 0;	
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "update managers set mname=?,msex=?,mphone=?,bid=?,mtype=?,musername=?,mpassword=? where mid =?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, m.getname());
			ps.setString(2, m.getsex());
			ps.setString(3, m.getphone());
			ps.setInt(4, m.getBid());
			ps.setString(5, m.getType());
			ps.setString(6, m.getusername());
			ps.setString(7, m.getpassword());
			ps.setInt(8, id);
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result==1?true:false;
	}
	public Manager getManagerById(int id) {
		Manager m = null;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select * from managers m,buildings b where m.bid=b.bid and m.mid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				m = (new Manager(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(9), rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return m;
	}
	public void updatePwd(int id,String pwd) {
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "update managers set mpassword=? where mid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, pwd);
			ps.setInt(2, id);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public List<Manager> getSuguan(){
		ArrayList<Manager> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from managers m,buildings b where m.bid=b.bid and m.mtype='manager' order by m.bid";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				list.add(new Manager(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(9), rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	//对应楼的管理员全部移除
	public void buildingInitManager(int bid) {
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "update managers set bid = 10 where bid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, bid);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//添加对应楼的管理员
	public void addManagerToBuilding(int mid,int bid) {
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "update managers set bid = ? where mid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, bid);
			ps.setInt(2, mid);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
