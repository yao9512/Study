package cn.yao.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.yao.controller.StudentServlet;
import cn.yao.controller.WorkServlet;
import cn.yao.entity.Absence;
import cn.yao.entity.Student;
import cn.yao.utils.DBUtils;

public class WorkDao {
	public List<Absence> findAll(int page,int pageSum){
		ArrayList<Absence> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select * from students s,buildings b,work w where s.bid = b.bid and w.sid=s.sid limit ?,?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, (page-1)*StudentServlet.PAGE_LIMIT);
			ps.setInt(2, pageSum);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Absence(rs.getInt("aid"),new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)),
							rs.getString("adate"),rs.getString("aintro")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public int getWorkCount() {
		int count = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select count(*) from work";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public List<Absence> findWorks(String date_s,String date_e,String bid,String searchType,String keyWord,int page,int pageSum){
		ArrayList<Absence> list = new ArrayList<>();
		String sql = "";
		PreparedStatement ps = null;
		try (Connection conn = DBUtils.getConnection();) {
			if("sname".equals(searchType)) {
				//名字模糊查询
				searchType =searchType + " like ";
				keyWord = "%"+keyWord+"%";
			}else {
				searchType = searchType + "=";
			}
			if("all".equals(bid)) {
				sql = "select * from students s,buildings b,work w "
						+ "where s.bid = b.bid and w.sid=s.sid and "
						+ "w.adate>? and w.adate<? and "+ searchType +"? limit ?,?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, date_s);
				ps.setString(2, date_e);
				ps.setString(3, keyWord);
				ps.setInt(4, (page-1)*WorkServlet.PAGE_LIMIT);
				ps.setInt(5, pageSum);
			}else {
				sql = "select * from students s,buildings b,work w "
						+ "where s.bid = b.bid and w.sid=s.sid and "
						+ "w.adate>? and w.adate<? and s.bid=? and "+ searchType +"? limit ?,?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, date_s);
				ps.setString(2, date_e);
				ps.setInt(3, Integer.parseInt(bid));
				ps.setString(4, keyWord);
				ps.setInt(5, (page-1)*WorkServlet.PAGE_LIMIT);
				ps.setInt(6, pageSum);
			}
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Absence(rs.getInt("aid"),new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)),
						rs.getString("adate"),rs.getString("aintro")));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public int findWorkCount(String date_s,String date_e,String bid,String searchType,String keyWord){
		int count = 0;
		String sql = "";
		PreparedStatement ps = null;
		try (Connection conn = DBUtils.getConnection();) {
			if("sname".equals(searchType)) {
				//名字模糊查询
				searchType =searchType + " like ";
				keyWord = "%"+keyWord+"%";
			}else {
				searchType = searchType + "=";
			}
			if("all".equals(bid)) {
				sql = "select count(*) from students s,buildings b,work w "
						+ "where s.bid = b.bid and w.sid=s.sid and "
						+ "w.adate>? and w.adate<? and "+ searchType +"?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, date_s);
				ps.setString(2, date_e);
				ps.setString(3, keyWord);
			}else {
				sql = "select count(*) from students s,buildings b,work w "
						+ "where s.bid = b.bid and w.sid=s.sid and "
						+ "w.adate>? and w.adate<? and s.bid=? and "+ searchType +"?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, date_s);
				ps.setString(2, date_e);
				ps.setInt(3, Integer.parseInt(bid));
				ps.setString(4, keyWord);
			}
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public boolean deleteById(int id) {
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "delete from work where aid =?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
}
