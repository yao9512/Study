package cn.yao.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.yao.controller.StudentServlet;
import cn.yao.controller.UserServlet;
import cn.yao.entity.Manager;
import cn.yao.entity.Student;
import cn.yao.utils.DBUtils;

public class StudentDao {
	public Student loginStudent(String username,String password) {
		Student s = null;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from students s,buildings b where s.bid=b.bid and susername=? and spassword=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				s = new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
	public List<Student> findAll(){
		ArrayList<Student> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select * from students s,buildings b where s.bid = b.bid";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				list.add(new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public List<Student> findAll(int page,int pageSum){
		ArrayList<Student> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select * from students s,buildings b where s.bid= b.bid limit ?,?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, (page-1)*StudentServlet.PAGE_LIMIT);
			ps.setInt(2, pageSum);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public int getStudentCount() {
		int count = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select count(*) from students";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public boolean addStudent(Student s) {
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "insert into students values(0,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, s.getname());
			ps.setString(2, s.getsex());
			ps.setString(3, s.getphone());
			ps.setInt(4, s.getBid());
			ps.setString(5, s.getDor());
			ps.setString(6, s.getusername());
			ps.setString(7, s	.getpassword());

			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	public boolean deleteById(int id) {
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "delete from students where sid =?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	public int getStudentsCountBySearch(String method,String bid,String keyWord) {
		int count = 0;
		String sql = null;
		PreparedStatement ps = null;
		try (Connection conn = DBUtils.getConnection();) {
			if("".equals(keyWord)) {
				//查找对应楼的所有学生
				sql = "select count(*) from students where bid=?";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, Integer.parseInt(bid));
			}else {
				//查找对应楼的相应method的学生
				if("sname".equals(method)) {
					//名字模糊查询
					method =method + " like ";
					keyWord = "%"+keyWord+"%";
				}else {
					method = method + "=";
				}
				if("all".equals(bid)) {
					sql = "select count(*) from students where "+method +"?";
					ps = conn.prepareStatement(sql);
					ps.setString(1, keyWord);
				}else {
					sql = "select count(*) from students where "+method +"? and bid=?";
					ps = conn.prepareStatement(sql);
					ps.setInt(2, Integer.parseInt(bid));
				}
				ps.setString(1, keyWord);
			}
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public List<Student> getStudents(String method,String bid,String keyWord,int page,int pageSum){
		ArrayList<Student> list = new ArrayList<>();
		String sql = null;
		PreparedStatement ps = null;
		try (Connection conn = DBUtils.getConnection();) {
			if("".equals(keyWord)) {
				//查找对应楼的所有学生
				sql = "select * from students s,buildings b where b.bid=s.bid and s.bid=? limit ?,?";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, Integer.parseInt(bid));
				ps.setInt(2, (page-1)*StudentServlet.PAGE_LIMIT);
				ps.setInt(3, pageSum);
			}else {
				//查找对应楼的相应method的学生
				if("sname".equals(method)) {
					//名字模糊查询
					method =method + " like ";
					keyWord = "%"+keyWord+"%";
				}else {
					method = method + "=";
				}
				if("all".equals(bid)) {
					sql = "select * from students s,buildings b where s.bid=b.bid and "+method +" ? limit ?,?";
					ps = conn.prepareStatement(sql);
					ps.setString(1, keyWord);
					ps.setInt(2, (page-1)*StudentServlet.PAGE_LIMIT);
					ps.setInt(3, pageSum);
				}else {
					sql = "select * from students s,buildings b where s.bid=b.bid and "+method +"? and s.bid=? limit ?,?";
					ps = conn.prepareStatement(sql);
					ps.setString(1, keyWord);
					ps.setInt(2, Integer.parseInt(bid));
					ps.setInt(3, (page-1)*StudentServlet.PAGE_LIMIT);
					ps.setInt(4, pageSum);
				}
				
			}
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public Student getStudentById(int id) {
		Student s = null;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select * from students s,buildings b where s.bid=b.bid and s.sid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				s = new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getString(10), rs.getString(6), rs.getString(7), rs.getString(8));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}

	public boolean updateById(int id, Student s) {
		int result = 0;	
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "update students set sname=?,ssex=?,sphone=?,bid=?,sdor=?,susername=?,spassword=? where sid =?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, s.getname());
			ps.setString(2, s.getsex());
			ps.setString(3, s.getphone());
			ps.setInt(4, s.getBid());
			ps.setString(5, s.getDor());
			ps.setString(6, s.getusername());
			ps.setString(7, s.getpassword());
			ps.setInt(8, id);
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result==1?true:false;
	}



}
