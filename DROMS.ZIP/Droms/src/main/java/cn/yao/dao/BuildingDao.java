package cn.yao.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.yao.controller.HouseServlet;
import cn.yao.controller.UserServlet;
import cn.yao.entity.Building;
import cn.yao.entity.Manager;
import cn.yao.utils.DBUtils;

public class BuildingDao {

	public List<Building> findAll(){
		ArrayList<Building> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select * from buildings order by bname";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				list.add(new Building(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public List<Building> findBuildings(int page,int pageSum){
		ArrayList<Building> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from buildings b order by bname limit ?,?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, (page-1)*HouseServlet.PAGE_LIMIT);
			ps.setInt(2, pageSum);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Building(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public int getBuildingCount() {
		int count = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select count(*) from buildings";
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public int getBuildingCountByName(String keyWord) {
		int count = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select count(*) from buildings where bname like ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "%"+keyWord+"%");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}
	public List<Building> findBuildingsByName(String keyWord,int page,int pageMax) {
		ArrayList<Building> list = new ArrayList<>();
		try (Connection conn = DBUtils.getConnection();) {
			String sql = " select * from buildings b where bname like ? limit ?,?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "%"+keyWord+"%");
			ps.setInt(2, (page-1)*HouseServlet.PAGE_LIMIT);
			ps.setInt(3, pageMax);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				list.add(new Building(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public boolean addBuilding(Building b) {
		int result = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "insert into buildings values(0,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, b.getBname());
			ps.setString(2, b.getBintro());
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result==1?true:false;
	}

	public boolean deleteById(int id) {
		int result = 0;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "delete from buildings where bid =?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result==1?true:false;		
	}

	public Building getBuildingById(int id) {
		Building m = null;
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "select * from buildings b where b.bid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				m = (new Building(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return m;
	}
	public boolean updateById(int id,Building b) {
		int result = 0;	
		try (Connection conn = DBUtils.getConnection();) {
			String sql = "update buildings set bname=?,bintro=? where bid =?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, b.getBname());
			ps.setString(2, b.getBintro());
			ps.setInt(3, b.getBid());
			result = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result==1?true:false;
	}
}
