package cn.yao.entity;

public class Student extends Person{

	private String dor;
	public Student(int id, String name, String sex, String phone,int bid, String bname, String dor,String username, String password) {
		super(id, name, sex, phone,bid, bname, username, password);
		this.dor = dor;
	}
	public String getDor() {
		return dor;
	}
	public void setDor(String dor) {
		this.dor = dor;
	}
	
}
