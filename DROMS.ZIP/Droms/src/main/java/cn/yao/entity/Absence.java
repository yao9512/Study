package cn.yao.entity;

public class Absence {

	private int id;
	private Student student;
	private String date;
	private String aintro;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getAintro() {
		return aintro;
	}
	public void setAintro(String aintro) {
		this.aintro = aintro;
	}
	public Absence(int id, Student student, String date, String aintro) {
		super();
		this.id = id;
		this.student = student;
		this.date = date;
		this.aintro = aintro;
	}
	@Override
	public String toString() {
		return "Absence [id=" + id + ", student=" + student + ", date=" + date + ", aintro=" + aintro + "]";
	}

	
	
}
