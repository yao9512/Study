package cn.yao.entity;

public class Manager extends Person{

	private String type;
	public Manager(int mid, String mname, String msex, String mphone,int bid, String bname, String type, String musername,
			String mpassword) {
		super(mid, mname, msex, mphone,bid, bname, musername, mpassword);
		this.type = type;
	}
	@Override
	public String toString() {
		return "Manager [mid=" + id + ", mname=" + name + ", msex=" + sex + ", mphone=" + phone +",bid="+bid+ ", bname=" + bname
				+ ", type=" + type + ", musername=" + username + ", mpassword=" + password + "]";
	}
	public String getType() {
			return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
