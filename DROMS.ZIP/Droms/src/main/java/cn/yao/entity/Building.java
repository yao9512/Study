package cn.yao.entity;

public class Building {

	private int bid;
	private String bname;
	private String bintro;
	public Building(int bid, String bname, String bintro) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.bintro = bintro;
	}
	@Override
	public String toString() {
		return "Building [bid=" + bid + ", bname=" + bname + ", bintro=" + bintro + "]";
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBintro() {
		return bintro;
	}
	public void setBintro(String bintro) {
		this.bintro = bintro;
	}
	
	
}
