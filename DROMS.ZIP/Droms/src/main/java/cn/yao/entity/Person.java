package cn.yao.entity;

public class Person {
	protected int id;
	protected String name;
	protected String sex;
	protected String phone;
	protected int bid;
	protected String bname;
	protected String username;
	protected String password;
	public Person(int id, String name, String sex, String phone,int bid, String bname, String username,
			String password) {
		super();
		this.id = id;
		this.name = name;
		this.sex = sex;
		this.phone = phone;
		this.bid = bid;
		this.bname = bname;
		this.username = username;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Manager [id=" + id + ", name=" + name + ", sex=" + sex + ", phone=" + phone +",bid="+bid+ ", bname=" + bname
				+  ", username=" + username + ", password=" + password + "]";
	}
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id = id;
	}
	public String getname() {
		return name;
	}
	public void setname(String name) {
		this.name = name;
	}
	public String getsex() {
		return sex;
	}
	public void setsex(String sex) {
		this.sex = sex;
	}
	public String getphone() {
		return phone;
	}
	public void setphone(String phone) {
		this.phone = phone;
	}
	public String getBname() {
		return bname;
	}
	public void setBid(String bname) {
		this.bname = bname;
	}
	public String getusername() {
		return username;
	}
	public void setusername(String username) {
		this.username = username;
	}
	public String getpassword() {
		return password;
	}
	public void setpassword(String password) {
		this.password = password;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
}
