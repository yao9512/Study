package cn.yao.entity;

public class ThPage {

	private int pageNum;
	private String pageState;
	public ThPage(int pageNum, String pageState) {
		super();
		this.pageNum = pageNum;
		this.pageState = pageState;
	}
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public String getPageState() {
		return pageState;
	}
	public void setPageState(String pageState) {
		this.pageState = pageState;
	}
	
	
}
